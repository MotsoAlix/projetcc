import '../models/payment.dart';

/// Service de paiement (Mock)
/// Simule les transactions de paiement
class PaymentService {
  /// Traite un paiement en espèces
  /// Retourne immédiatement un paiement validé
  Future<Payment> processCashPayment({
    required String orderId,
    required double amount,
  }) async {
    // Simulation délai de validation
    await Future.delayed(const Duration(seconds: 1));

    return Payment(
      id: 'PAY-${DateTime.now().millisecondsSinceEpoch}',
      orderId: orderId,
      amount: amount,
      method: 'cash',
      status: 'paid',
      paidAt: DateTime.now(),
      transactionId: 'CASH-${DateTime.now().millisecondsSinceEpoch}',
    );
  }

  /// Traite un paiement par carte bancaire
  /// Simule une transaction avec délai
  Future<Payment> processCardPayment({
    required String orderId,
    required double amount,
    required String cardNumber,
    required String cardHolder,
    required String expiryDate,
    required String cvv,
  }) async {
    // Simulation traitement bancaire (2 secondes)
    await Future.delayed(const Duration(seconds: 2));

    // Validation basique du numéro de carte (pour la démo)
    if (cardNumber.length < 16) {
      throw Exception('Numéro de carte invalide');
    }

    return Payment(
      id: 'PAY-${DateTime.now().millisecondsSinceEpoch}',
      orderId: orderId,
      amount: amount,
      method: 'card',
      status: 'paid',
      paidAt: DateTime.now(),
      transactionId: 'CARD-${DateTime.now().millisecondsSinceEpoch}',
    );
  }

  /// Traite un paiement Mobile Money
  /// Simule une transaction MTN/Orange Money
  Future<Payment> processMobileMoneyPayment({
    required String orderId,
    required double amount,
    required String phoneNumber,
  }) async {
    // Simulation envoi notification USSD
    await Future.delayed(const Duration(seconds: 1));

    // Validation du numéro
    if (phoneNumber.length < 9) {
      throw Exception('Numéro de téléphone invalide');
    }

    // Simulation attente validation client (3 secondes)
    await Future.delayed(const Duration(seconds: 2));

    return Payment(
      id: 'PAY-${DateTime.now().millisecondsSinceEpoch}',
      orderId: orderId,
      amount: amount,
      method: 'mobile_money',
      status: 'paid',
      paidAt: DateTime.now(),
      transactionId: 'MM-${DateTime.now().millisecondsSinceEpoch}',
      phoneNumber: phoneNumber,
    );
  }

  /// Récupère l'historique des paiements
  Future<List<Payment>> getPaymentHistory(String userId) async {
    await Future.delayed(const Duration(milliseconds: 500));

    // Pour la démo, retourner une liste vide
    // Dans une vraie app, on récupérerait les paiements du user
    return [];
  }

  /// Vérifie le statut d'un paiement
  Future<Payment?> checkPaymentStatus(String paymentId) async {
    await Future.delayed(const Duration(milliseconds: 300));

    // Simulation: toujours retourner null (pas trouvé)
    // Dans une vraie app, on chercherait dans la base
    return null;
  }

  /// Simule un remboursement (Admin uniquement)
  Future<Payment> refundPayment(Payment payment) async {
    await Future.delayed(const Duration(seconds: 1));

    return payment.copyWith(
      status: 'refunded',
    );
  }
}