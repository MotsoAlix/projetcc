import '../models/order.dart';
import '../models/payment.dart';

/// Service de gestion des commandes (Mock)
class OrderService {
  /// Base de données commandes simulée (en mémoire)
  static final List<Order> _orders = [
    Order(
      id: 'ORD-20260130-001',
      clientId: '4',
      clientName: 'Paul Client',
      pressingId: 'press_1',
      pressingName: 'Pressing Deluxe',
      services: [
        ServiceItem(id: 'dry_clean', name: 'Nettoyage à sec', quantity: 2, price: 5000),
        ServiceItem(id: 'ironing', name: 'Repassage', quantity: 1, price: 2000),
      ],
      photoUrls: [],
      status: 'pending',
      total: 12000,
      createdAt: DateTime.now().subtract(const Duration(hours: 2)),
      notes: 'Urgent - Mariage ce weekend',
    ),
    Order(
      id: 'ORD-20260129-042',
      clientId: '4',
      clientName: 'Paul Client',
      pressingId: 'press_1',
      pressingName: 'Pressing Deluxe',
      services: [
        ServiceItem(id: 'dry_clean', name: 'Nettoyage à sec', quantity: 3, price: 5000),
      ],
      photoUrls: [],
      status: 'ready',
      total: 15000,
      payment: Payment(
        id: 'PAY-001',
        orderId: 'ORD-20260129-042',
        amount: 15000,
        method: 'mobile_money',
        status: 'paid',
        paidAt: DateTime.now().subtract(const Duration(hours: 24)),
        transactionId: 'MTN-123456789',
        phoneNumber: '6XXXXXXXX',
      ),
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
      readyAt: DateTime.now().subtract(const Duration(hours: 1)),
    ),
  ];

  /// Récupère toutes les commandes
  Future<List<Order>> getAllOrders() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return List.from(_orders);
  }

  /// Récupère les commandes d'un client
  Future<List<Order>> getOrdersByClient(String clientId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _orders.where((o) => o.clientId == clientId).toList();
  }

  /// Récupère les commandes d'un pressing
  Future<List<Order>> getOrdersByPressing(String pressingId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _orders.where((o) => o.pressingId == pressingId).toList();
  }

  /// Récupère une commande par ID
  Future<Order?> getOrderById(String orderId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    try {
      return _orders.firstWhere((o) => o.id == orderId);
    } catch (e) {
      return null;
    }
  }

  /// Crée une nouvelle commande
  Future<Order> createOrder({
    required String clientId,
    required String clientName,
    required String pressingId,
    required String pressingName,
    required List<ServiceItem> services,
    List<String> photoUrls = const [],
    String? notes,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    // Calcul du total
    double total = services.fold(0, (sum, service) => sum + service.subtotal);

    // Génération ID unique
    final now = DateTime.now();
    final dateStr = '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}';
    final orderNumber = (_orders.length + 1).toString().padLeft(3, '0');
    final orderId = 'ORD-$dateStr-$orderNumber';

    final newOrder = Order(
      id: orderId,
      clientId: clientId,
      clientName: clientName,
      pressingId: pressingId,
      pressingName: pressingName,
      services: services,
      photoUrls: photoUrls,
      status: 'pending',
      total: total,
      createdAt: now,
      notes: notes,
    );

    _orders.insert(0, newOrder); // Ajouter en début de liste
    return newOrder;
  }

  /// Met à jour le statut d'une commande
  Future<Order> updateOrderStatus(String orderId, String newStatus) async {
    await Future.delayed(const Duration(milliseconds: 500));

    final index = _orders.indexWhere((o) => o.id == orderId);
    if (index == -1) {
      throw Exception('Commande non trouvée');
    }

    final updatedOrder = _orders[index].copyWith(
      status: newStatus,
      readyAt: newStatus == 'ready' ? DateTime.now() : _orders[index].readyAt,
      deliveredAt: newStatus == 'delivered' ? DateTime.now() : _orders[index].deliveredAt,
    );

    _orders[index] = updatedOrder;
    return updatedOrder;
  }

  /// Ajoute un paiement à une commande
  Future<Order> addPayment(String orderId, Payment payment) async {
    await Future.delayed(const Duration(milliseconds: 500));

    final index = _orders.indexWhere((o) => o.id == orderId);
    if (index == -1) {
      throw Exception('Commande non trouvée');
    }

    final updatedOrder = _orders[index].copyWith(payment: payment);
    _orders[index] = updatedOrder;
    return updatedOrder;
  }

  /// Récupère les statistiques (pour dashboard Admin/Manager)
  Future<Map<String, dynamic>> getStatistics({String? pressingId}) async {
    await Future.delayed(const Duration(milliseconds: 500));

    List<Order> filteredOrders = pressingId != null
        ? _orders.where((o) => o.pressingId == pressingId).toList()
        : _orders;

    final totalOrders = filteredOrders.length;
    final pendingOrders = filteredOrders.where((o) => o.status == 'pending').length;
    final inProgressOrders = filteredOrders.where((o) => o.status == 'in_progress').length;
    final readyOrders = filteredOrders.where((o) => o.status == 'ready').length;
    final deliveredOrders = filteredOrders.where((o) => o.status == 'delivered').length;

    final totalRevenue = filteredOrders
        .where((o) => o.payment?.isPaid ?? false)
        .fold<double>(0, (sum, o) => sum + o.total);

    final pendingPayments = filteredOrders
        .where((o) => o.payment == null || !o.payment!.isPaid)
        .fold<double>(0, (sum, o) => sum + o.total);

    return {
      'totalOrders': totalOrders,
      'pendingOrders': pendingOrders,
      'inProgressOrders': inProgressOrders,
      'readyOrders': readyOrders,
      'deliveredOrders': deliveredOrders,
      'totalRevenue': totalRevenue,
      'pendingPayments': pendingPayments,
    };
  }

  /// Supprime une commande (Admin uniquement)
  Future<void> deleteOrder(String orderId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _orders.removeWhere((o) => o.id == orderId);
  }
}