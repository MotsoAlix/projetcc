import '../models/user.dart';

/// Service d'authentification (Mock)
/// Simule une API backend pour la connexion/déconnexion
class AuthService {
  /// Base de données utilisateurs simulée (en mémoire)
  static final List<User> _users = [
    User(
      id: '1',
      name: 'Administrateur',
      email: 'admin@pressing.com',
      role: 'admin',
      phone: '+237 600 00 00 01',
    ),
    User(
      id: '2',
      name: 'Jean Manager',
      email: 'manager@pressing.com',
      role: 'manager',
      pressingId: 'press_1',
      phone: '+237 600 00 00 02',
    ),
    User(
      id: '3',
      name: 'Marie Employée',
      email: 'employee@pressing.com',
      role: 'employee',
      pressingId: 'press_1',
      phone: '+237 600 00 00 03',
    ),
    User(
      id: '4',
      name: 'Paul Client',
      email: 'client@pressing.com',
      role: 'client',
      phone: '+237 600 00 00 04',
    ),
  ];

  /// Base de données pressings simulée
  static final List<Pressing> _pressings = [
    Pressing(
      id: 'press_1',
      name: 'Pressing Deluxe',
      address: '123 Avenue de la République, Douala',
      phone: '+237 233 XX XX XX',
      managerId: '2',
    ),
    Pressing(
      id: 'press_2',
      name: 'Clean Express',
      address: '45 Rue des Palmiers, Yaoundé',
      phone: '+237 222 XX XX XX',
      managerId: '5', // Manager fictif
    ),
  ];

  /// Simule une connexion (délai réseau 1 seconde)
  /// Retourne l'utilisateur si email/password valides
  /// Lance une exception sinon
  Future<User> login(String email, String password) async {
    // Simulation délai réseau
    await Future.delayed(const Duration(seconds: 1));

    // Pour la démo, tous les mots de passe sont "password123"
    if (password != 'password123') {
      throw Exception('Mot de passe incorrect');
    }

    // Recherche utilisateur par email
    try {
      return _users.firstWhere(
            (user) => user.email.toLowerCase() == email.toLowerCase(),
      );
    } catch (e) {
      throw Exception('Utilisateur non trouvé');
    }
  }

  /// Simule une déconnexion
  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 300));
    // Rien à faire côté serveur pour le mock
  }

  /// Récupère un utilisateur par son ID
  User? getUserById(String id) {
    try {
      return _users.firstWhere((user) => user.id == id);
    } catch (e) {
      return null;
    }
  }

  /// Récupère tous les utilisateurs (pour Admin)
  Future<List<User>> getAllUsers() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return List.from(_users);
  }

  /// Récupère tous les gérants (pour Admin)
  Future<List<User>> getManagers() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _users.where((u) => u.role == 'manager').toList();
  }

  /// Récupère tous les employés d'un pressing (pour Manager)
  Future<List<User>> getEmployeesByPressing(String pressingId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return _users
        .where((u) => u.role == 'employee' && u.pressingId == pressingId)
        .toList();
  }

  /// Ajoute un nouveau gérant (ADMIN uniquement)
  Future<User> addManager({
    required String name,
    required String email,
    required String phone,
    required String pressingId,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    // Vérifier que l'email n'existe pas déjà
    if (_users.any((u) => u.email == email)) {
      throw Exception('Cet email est déjà utilisé');
    }

    final newManager = User(
      id: 'user_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      email: email,
      role: 'manager',
      pressingId: pressingId,
      phone: phone,
    );

    _users.add(newManager);
    return newManager;
  }

  /// Ajoute un nouveau employé (MANAGER uniquement)
  Future<User> addEmployee({
    required String name,
    required String email,
    required String phone,
    required String pressingId,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    if (_users.any((u) => u.email == email)) {
      throw Exception('Cet email est déjà utilisé');
    }

    final newEmployee = User(
      id: 'user_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      email: email,
      role: 'employee',
      pressingId: pressingId,
      phone: phone,
    );

    _users.add(newEmployee);
    return newEmployee;
  }

  /// Récupère tous les pressings
  Future<List<Pressing>> getAllPressings() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return List.from(_pressings);
  }

  /// Récupère un pressing par ID
  Pressing? getPressingById(String id) {
    try {
      return _pressings.firstWhere((p) => p.id == id);
    } catch (e) {
      return null;
    }
  }

  /// Ajoute un nouveau pressing (ADMIN uniquement)
  Future<Pressing> addPressing({
    required String name,
    required String address,
    required String phone,
    required String managerId,
  }) async {
    await Future.delayed(const Duration(seconds: 1));

    final newPressing = Pressing(
      id: 'press_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      address: address,
      phone: phone,
      managerId: managerId,
    );

    _pressings.add(newPressing);
    return newPressing;
  }
}