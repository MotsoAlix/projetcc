import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';

/// Provider pour gérer l'état d'authentification
class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  final StorageService _storageService = StorageService();

  User? _currentUser;
  bool _isLoading = false;
  String? _error;

  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _currentUser != null;

  /// Vérifie si l'utilisateur est admin
  bool get isAdmin => _currentUser?.isAdmin ?? false;

  /// Vérifie si l'utilisateur est manager
  bool get isManager => _currentUser?.isManager ?? false;

  /// Vérifie si l'utilisateur est employé
  bool get isEmployee => _currentUser?.isEmployee ?? false;

  /// Vérifie si l'utilisateur est client
  bool get isClient => _currentUser?.isClient ?? false;

  AuthProvider() {
    _loadSavedUser();
  }

  /// Charge l'utilisateur sauvegardé au démarrage
  Future<void> _loadSavedUser() async {
    _isLoading = true;
    notifyListeners();

    try {
      final user = await _storageService.getUser();
      if (user != null) {
        _currentUser = user;
      }
    } catch (e) {
      _error = 'Erreur de chargement: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Connexion
  Future<bool> login(String email, String password) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final user = await _authService.login(email, password);
      _currentUser = user;

      // Sauvegarde locale
      await _storageService.saveUser(user);
      await _storageService.saveToken('fake-jwt-token-${user.id}');

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString().replaceAll('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Déconnexion
  Future<void> logout() async {
    _isLoading = true;
    notifyListeners();

    try {
      await _authService.logout();
      await _storageService.clearAuth();
      _currentUser = null;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Efface les erreurs
  void clearError() {
    _error = null;
    notifyListeners();
  }
}