import 'package:flutter/foundation.dart';
import '../models/order.dart';
import '../models/payment.dart';
import '../services/order_service.dart';
import '../services/payment_service.dart';

/// Provider pour gérer l'état des commandes
class OrderProvider with ChangeNotifier {
  final OrderService _orderService = OrderService();
  final PaymentService _paymentService = PaymentService();

  List<Order> _orders = [];
  Order? _currentOrder;
  bool _isLoading = false;
  String? _error;

  List<Order> get orders => _orders;
  Order? get currentOrder => _currentOrder;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Charge toutes les commandes
  Future<void> loadAllOrders() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _orders = await _orderService.getAllOrders();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Charge les commandes d'un client
  Future<void> loadClientOrders(String clientId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _orders = await _orderService.getOrdersByClient(clientId);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Charge les commandes d'un pressing
  Future<void> loadPressingOrders(String pressingId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _orders = await _orderService.getOrdersByPressing(pressingId);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Charge une commande spécifique
  Future<void> loadOrder(String orderId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _currentOrder = await _orderService.getOrderById(orderId);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Crée une nouvelle commande
  Future<Order?> createOrder({
    required String clientId,
    required String clientName,
    required String pressingId,
    required String pressingName,
    required List<ServiceItem> services,
    List<String> photoUrls = const [],
    String? notes,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final order = await _orderService.createOrder(
        clientId: clientId,
        clientName: clientName,
        pressingId: pressingId,
        pressingName: pressingName,
        services: services,
        photoUrls: photoUrls,
        notes: notes,
      );

      _orders.insert(0, order);
      _currentOrder = order;

      _isLoading = false;
      notifyListeners();
      return order;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  /// Met à jour le statut d'une commande
  Future<bool> updateOrderStatus(String orderId, String newStatus) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final updatedOrder = await _orderService.updateOrderStatus(orderId, newStatus);

      // Mettre à jour dans la liste
      final index = _orders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        _orders[index] = updatedOrder;
      }

      if (_currentOrder?.id == orderId) {
        _currentOrder = updatedOrder;
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Traite un paiement en espèces
  Future<bool> payCash(String orderId, double amount) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final payment = await _paymentService.processCashPayment(
        orderId: orderId,
        amount: amount,
      );

      final updatedOrder = await _orderService.addPayment(orderId, payment);

      // Mise à jour locale
      final index = _orders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        _orders[index] = updatedOrder;
      }

      if (_currentOrder?.id == orderId) {
        _currentOrder = updatedOrder;
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Traite un paiement par carte
  Future<bool> payByCard({
    required String orderId,
    required double amount,
    required String cardNumber,
    required String cardHolder,
    required String expiryDate,
    required String cvv,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final payment = await _paymentService.processCardPayment(
        orderId: orderId,
        amount: amount,
        cardNumber: cardNumber,
        cardHolder: cardHolder,
        expiryDate: expiryDate,
        cvv: cvv,
      );

      final updatedOrder = await _orderService.addPayment(orderId, payment);

      final index = _orders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        _orders[index] = updatedOrder;
      }

      if (_currentOrder?.id == orderId) {
        _currentOrder = updatedOrder;
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Traite un paiement Mobile Money
  Future<bool> payByMobileMoney({
    required String orderId,
    required double amount,
    required String phoneNumber,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final payment = await _paymentService.processMobileMoneyPayment(
        orderId: orderId,
        amount: amount,
        phoneNumber: phoneNumber,
      );

      final updatedOrder = await _orderService.addPayment(orderId, payment);

      final index = _orders.indexWhere((o) => o.id == orderId);
      if (index != -1) {
        _orders[index] = updatedOrder;
      }

      if (_currentOrder?.id == orderId) {
        _currentOrder = updatedOrder;
      }

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Efface les erreurs
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// Sélectionne une commande courante
  void setCurrentOrder(Order order) {
    _currentOrder = order;
    notifyListeners();
  }
}