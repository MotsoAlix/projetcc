import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../client/create_order_screen.dart';

class ManagerHome extends StatefulWidget {
  const ManagerHome({Key? key}) : super(key: key);

  @override
  State<ManagerHome> createState() => _ManagerHomeState();
}

class _ManagerHomeState extends State<ManagerHome> {
  @override
  void initState() {
    super.initState();
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final orders = Provider.of<OrderProvider>(context, listen: false);
    if (auth.currentUser?.pressingId != null) {
      orders.loadPressingOrders(auth.currentUser!.pressingId!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final user = auth.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manager Dashboard'),
        actions: [
          if (user != null)
            PopupMenuButton<int>(
              icon: CircleAvatar(
                backgroundColor: Colors.purple.shade100,
                child: Text(
                  user.name.isNotEmpty ? user.name[0].toUpperCase() : 'M',
                  style: const TextStyle(color: Colors.purple),
                ),
              ),
              onSelected: (value) {
                if (value == 1) auth.logout();
              },
              itemBuilder: (context) => [
                PopupMenuItem<int>(
                  value: 0,
                  child: Text(user.name.isNotEmpty ? user.name : 'Manager'),
                ),
                const PopupMenuDivider(),
                const PopupMenuItem<int>(
                  value: 1,
                  child: Row(
                    children: [
                      Icon(Icons.logout, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Déconnexion'),
                    ],
                  ),
                ),
              ],
            ),
        ],
      ),

      body: Consumer<OrderProvider>(
        builder: (context, orders, _) {
          if (orders.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          final allOrders = orders.orders;
          final totalOrders = allOrders.length;
          final pendingOrders =
              allOrders.where((o) => o.status == 'pending').length;
          final inProgressOrders =
              allOrders.where((o) => o.status == 'in_progress').length;
          final readyOrders =
              allOrders.where((o) => o.status == 'ready').length;

          final stats = [
            {'label': 'Total', 'value': totalOrders, 'icon': Icons.shopping_bag, 'color': Colors.blue},
            {'label': 'En attente', 'value': pendingOrders, 'icon': Icons.schedule, 'color': Colors.orange},
            {'label': 'En cours', 'value': inProgressOrders, 'icon': Icons.autorenew, 'color': Colors.purple},
            {'label': 'Prêtes', 'value': readyOrders, 'icon': Icons.check_circle, 'color': Colors.green},
          ];

          final pendingList = allOrders
              .where((o) => o.status == 'pending' || o.status == 'in_progress')
              .toList();

          return Column(
            children: [
              // Stats cards horizontales responsive
              SizedBox(
                height: 140,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  scrollDirection: Axis.horizontal,
                  itemCount: stats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 16),
                  itemBuilder: (context, index) {
                    final stat = stats[index];
                    final label = stat['label'] as String? ?? '';
                    final value = stat['value'] as int? ?? 0;
                    final icon = stat['icon'] as IconData? ?? Icons.info;
                    final color = stat['color'] as Color? ?? Colors.grey;

                    return ConstrainedBox(
                      constraints: const BoxConstraints(
                        minWidth: 120,
                        maxWidth: 160,
                      ),
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        color: color.withOpacity(0.1),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(icon, size: 36, color: color),
                              const SizedBox(height: 8),
                              Text(
                                value.toString(),
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: color,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                label,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Colors.black54),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text(
                      'Commandes récentes',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),

              Expanded(
                child: pendingList.isEmpty
                    ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.inbox_outlined, size: 80, color: Colors.grey),
                      SizedBox(height: 16),
                      Text(
                        'Aucune commande en attente',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Créez une nouvelle commande pour vos clients',
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                )
                    : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: pendingList.length,
                  itemBuilder: (context, index) {
                    final order = pendingList[index];
                    final clientName =
                    (order.clientName.isNotEmpty) ? order.clientName : 'Client';
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: order.isPaid ? Colors.green.shade100 : Colors.orange.shade100,
                          child: Text(
                            clientName[0].toUpperCase(),
                            style: TextStyle(
                              color: order.isPaid ? Colors.green : Colors.orange,
                            ),
                          ),
                        ),
                        title: Text(order.id),
                        subtitle: Text(clientName),
                        trailing: Text(
                          '${order.total.toStringAsFixed(0)} FCFA',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const CreateOrderScreen()),
          );
        },
        icon: const Icon(Icons.add),
        label: const Text('Nouvelle Commande'),
      ),
    );
  }
}
