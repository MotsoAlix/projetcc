import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';

/// Écran d'accueil Admin moderne et animé
class AdminHome extends StatefulWidget {
  const AdminHome({Key? key}) : super(key: key);

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> with SingleTickerProviderStateMixin {
  int _currentTabIndex = 0;

  @override
  void initState() {
    super.initState();
    Provider.of<OrderProvider>(context, listen: false).loadAllOrders();
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        elevation: 0,
        backgroundColor: Colors.blueAccent,
        actions: [
          PopupMenuButton<int>(
            icon: CircleAvatar(
              backgroundColor: Colors.white,
              child: Text(
                auth.currentUser?.name[0].toUpperCase() ?? 'A',
                style: const TextStyle(color: Colors.blueAccent),
              ),
            ),
            onSelected: (value) {
              if (value == 1) auth.logout();
            },
            itemBuilder: (context) => [
              PopupMenuItem<int>(
                value: 0,
                enabled: false,
                child: Text(auth.currentUser?.name ?? 'Admin'),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem<int>(
                value: 1,
                child: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Déconnexion'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(width: 8),
        ],
      ),

      // BODY avec IndexedStack pour garder l'état des pages
      body: IndexedStack(
        index: _currentTabIndex,
        children: [
          _buildDashboard(),
          _buildManagersTab(),
          _buildOrdersTab(),
        ],
      ),

      // BOTTOM NAVIGATION BAR
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTabIndex,
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _currentTabIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Gérants'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: 'Commandes'),
        ],
      ),
    );
  }

  /// DASHBOARD MODERNE AVEC ANIMATIONS
  Widget _buildDashboard() {
    return Consumer<OrderProvider>(builder: (context, orders, _) {
      if (orders.isLoading) {
        return const Center(child: CircularProgressIndicator());
      }

      final stats = [
        {
          'label': 'Total Commandes',
          'value': orders.orders.length,
          'icon': Icons.shopping_bag,
          'color': Colors.blue,
        },
        {
          'label': 'En attente',
          'value': orders.orders.where((o) => o.status == 'pending').length,
          'icon': Icons.schedule,
          'color': Colors.orange,
        },
        {
          'label': 'En cours',
          'value': orders.orders.where((o) => o.status == 'in_progress').length,
          'icon': Icons.autorenew,
          'color': Colors.purple,
        },
        {
          'label': 'Prêtes',
          'value': orders.orders.where((o) => o.status == 'ready').length,
          'icon': Icons.check_circle,
          'color': Colors.green,
        },
        {
          'label': 'Revenu Total',
          'value': orders.orders.where((o) => o.isPaid).fold<double>(0, (sum, o) => sum + o.total),
          'icon': Icons.attach_money,
          'color': Colors.teal,
        },
        {
          'label': 'Pressings',
          'value': 2,
          'icon': Icons.store,
          'color': Colors.indigo,
        },
      ];

      return Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          itemCount: stats.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.3,
          ),
          itemBuilder: (context, index) {
            final stat = stats[index];
            return _buildAnimatedCard(
              stat['label'] as String,
              stat['value'] as num,
              stat['icon'] as IconData,
              stat['color'] as Color,
            );
          },
        ),
      );
    });
  }

  /// CARD ANIMÉE
  Widget _buildAnimatedCard(String label, num value, IconData icon, Color color) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: value.toDouble()),
      duration: const Duration(milliseconds: 800),
      curve: Curves.easeOutCubic,
      builder: (context, animatedValue, child) {
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color.withOpacity(0.2), color.withOpacity(0.5)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(2, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 40, color: color),
                const SizedBox(height: 12),
                Text(
                  animatedValue % 1 == 0
                      ? animatedValue.toInt().toString()
                      : animatedValue.toStringAsFixed(2),
                  style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: color),
                ),
                const SizedBox(height: 6),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.black87, fontSize: 14),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// GÉRANTS AVEC CONTENU POUR PAGE VIDE
  Widget _buildManagersTab() {
    return Consumer<OrderProvider>(builder: (context, orders, _) {
      final managers = <Map<String, String>>[
        {'name': 'Jean Manager', 'email': 'manager@pressing.com', 'pressing': 'Pressing Deluxe'},
        {'name': 'Marie Gérante', 'email': 'marie@pressing.com', 'pressing': 'Clean Express'},
      ];

      if (managers.isEmpty) {
        return _buildEmptyPage(
          icon: Icons.people_outline,
          message: 'Aucun gérant ajouté',
          subMessage: 'Ajoutez un gérant en cliquant sur le bouton ci-dessus.',
        );
      }

      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton.icon(
            onPressed: _showAddManagerDialog,
            icon: const Icon(Icons.add),
            label: const Text('Ajouter un gérant'),
          ),
          const SizedBox(height: 16),
          ...managers.map((manager) => Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: CircleAvatar(child: Text(manager['name']![0])),
              title: Text(manager['name']!),
              subtitle: Text('${manager['email']} - ${manager['pressing']}'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            ),
          )),
        ],
      );
    });
  }

  /// COMMANDES AVEC CONTENU POUR PAGE VIDE
  Widget _buildOrdersTab() {
    return Consumer<OrderProvider>(builder: (context, orders, _) {
      if (orders.isLoading) {
        return const Center(child: CircularProgressIndicator());
      }

      if (orders.orders.isEmpty) {
        return _buildEmptyPage(
          icon: Icons.shopping_cart_outlined,
          message: 'Aucune commande',
          subMessage: 'Les commandes passées par les clients apparaîtront ici.',
        );
      }

      return ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: orders.orders.length,
        itemBuilder: (context, index) {
          final order = orders.orders[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: Icon(
                Icons.shopping_bag,
                color: order.isPaid ? Colors.green : Colors.orange,
              ),
              title: Text(order.id),
              subtitle: Text('${order.clientName} - ${order.pressingName}'),
              trailing: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${order.total.toStringAsFixed(0)} FCFA',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    order.statusLabel,
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
          );
        },
      );
    });
  }

  /// PAGE VIDE MODERNE
  Widget _buildEmptyPage({required IconData icon, required String message, required String subMessage}) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 80, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          Text(
            message,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            subMessage,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  /// DIALOGUE AJOUT MANAGER
  void _showAddManagerDialog() {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ajouter un gérant'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Nom complet'),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: phoneController,
              decoration: const InputDecoration(labelText: 'Téléphone'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Annuler'),
          ),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Gérant ajouté avec succès '),
                  backgroundColor: Colors.green,
                ),
              );
              Navigator.pop(context);
            },
            child: const Text('Ajouter'),
          ),
        ],
      ),
    );
  }
}
