import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/order.dart';
import '../../providers/order_provider.dart';
import 'receipt_screen.dart';

/// Écran de paiement
class PaymentScreen extends StatefulWidget {
  final Order order;

  const PaymentScreen({Key? key, required this.order}) : super(key: key);

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedMethod = 'cash'; // cash, card, mobile_money
  bool _isProcessing = false;

  // Formulaire carte
  final _cardFormKey = GlobalKey<FormState>();
  final _cardNumberController = TextEditingController();
  final _cardHolderController = TextEditingController();
  final _expiryDateController = TextEditingController();
  final _cvvController = TextEditingController();

  // Formulaire Mobile Money
  final _mobileFormKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();

  @override
  void dispose() {
    _cardNumberController.dispose();
    _cardHolderController.dispose();
    _expiryDateController.dispose();
    _cvvController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _processPayment() async {
    setState(() {
      _isProcessing = true;
    });

    final orderProvider = Provider.of<OrderProvider>(context, listen: false);
    bool success = false;

    try {
      switch (_selectedMethod) {
        case 'cash':
          success = await orderProvider.payCash(
            widget.order.id,
            widget.order.total,
          );
          break;

        case 'card':
          if (!_cardFormKey.currentState!.validate()) {
            setState(() {
              _isProcessing = false;
            });
            return;
          }

          success = await orderProvider.payByCard(
            orderId: widget.order.id,
            amount: widget.order.total,
            cardNumber: _cardNumberController.text,
            cardHolder: _cardHolderController.text,
            expiryDate: _expiryDateController.text,
            cvv: _cvvController.text,
          );
          break;

        case 'mobile_money':
          if (!_mobileFormKey.currentState!.validate()) {
            setState(() {
              _isProcessing = false;
            });
            return;
          }

          success = await orderProvider.payByMobileMoney(
            orderId: widget.order.id,
            amount: widget.order.total,
            phoneNumber: _phoneController.text,
          );
          break;
      }

      setState(() {
        _isProcessing = false;
      });

      if (success && mounted) {
        // Rediriger vers le reçu
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (_) => ReceiptScreen(order: orderProvider.currentOrder!),
          ),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(orderProvider.error ?? 'Échec du paiement'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      setState(() {
        _isProcessing = false;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Paiement'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Montant à payer
          Card(
            color: Colors.blue.shade50,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text(
                    'Montant à payer',
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${widget.order.total.toStringAsFixed(0)} FCFA',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          const Text(
            'Choisir un moyen de paiement',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 16),

          // Espèces
          _buildPaymentMethodTile(
            'cash',
            'Espèces',
            Icons.money,
            'Paiement en espèces au pressing',
          ),

          // Carte bancaire
          _buildPaymentMethodTile(
            'card',
            'Carte bancaire',
            Icons.credit_card,
            'Paiement sécurisé par carte',
          ),

          // Mobile Money
          _buildPaymentMethodTile(
            'mobile_money',
            'Mobile Money',
            Icons.phone_android,
            'MTN, Orange Money, etc.',
          ),

          const SizedBox(height: 24),

          // Formulaire selon la méthode
          if (_selectedMethod == 'card') _buildCardForm(),
          if (_selectedMethod == 'mobile_money') _buildMobileMoneyForm(),

          const SizedBox(height: 24),

          // Bouton de paiement
          SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: _isProcessing ? null : _processPayment,
              child: _isProcessing
                  ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
                  : const Text(
                'Confirmer le paiement',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodTile(
      String value,
      String title,
      IconData icon,
      String subtitle,
      ) {
    final isSelected = _selectedMethod == value;

    return Card(
      color: isSelected ? Colors.blue.shade50 : null,
      child: RadioListTile<String>(
        value: value,
        groupValue: _selectedMethod,
        onChanged: _isProcessing
            ? null
            : (val) {
          setState(() {
            _selectedMethod = val!;
          });
        },
        title: Row(
          children: [
            Icon(icon, color: isSelected ? Colors.blue : Colors.grey),
            const SizedBox(width: 8),
            Text(title),
          ],
        ),
        subtitle: Text(subtitle),
      ),
    );
  }

  Widget _buildCardForm() {
    return Form(
      key: _cardFormKey,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Informations de la carte',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _cardNumberController,
                decoration: const InputDecoration(
                  labelText: 'Numéro de carte',
                  hintText: '1234 5678 9012 3456',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Requis';
                  }
                  if (value.replaceAll(' ', '').length < 16) {
                    return 'Numéro invalide';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _cardHolderController,
                decoration: const InputDecoration(
                  labelText: 'Titulaire de la carte',
                  hintText: 'JEAN DUPONT',
                  border: OutlineInputBorder(),
                ),
                textCapitalization: TextCapitalization.characters,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Requis';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _expiryDateController,
                      decoration: const InputDecoration(
                        labelText: 'Expiration',
                        hintText: 'MM/AA',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Requis';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _cvvController,
                      decoration: const InputDecoration(
                        labelText: 'CVV',
                        hintText: '123',
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.number,
                      obscureText: true,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Requis';
                        }
                        if (value.length < 3) {
                          return 'Invalide';
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMobileMoneyForm() {
    return Form(
      key: _mobileFormKey,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Numéro Mobile Money',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(
                  labelText: 'Numéro de téléphone',
                  hintText: '6XXXXXXXX',
                  prefixText: '+237 ',
                  border: OutlineInputBorder(),
                  helperText: 'MTN, Orange Money, etc.',
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Numéro requis';
                  }
                  if (value.length < 9) {
                    return 'Numéro invalide';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.blue.shade700),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Vous recevrez une notification pour valider le paiement',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}