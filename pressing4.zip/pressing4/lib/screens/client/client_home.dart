import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order.dart';
import '../client/create_order_screen.dart';
import 'order_details_screen.dart';

class ClientHome extends StatefulWidget {
  const ClientHome({Key? key}) : super(key: key);

  @override
  State<ClientHome> createState() => _ClientHomeState();
}

class _ClientHomeState extends State<ClientHome>
    with SingleTickerProviderStateMixin {
  int _currentTabIndex = 0;

  late final AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _loadOrders();
    _animationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadOrders() async {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    final orders = Provider.of<OrderProvider>(context, listen: false);
    if (auth.currentUser != null) {
      await orders.loadClientOrders(auth.currentUser!.id);
    }
  }

  void _onTabChanged(int index) {
    setState(() {
      _currentTabIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final user = auth.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes Commandes'),
        actions: [
          PopupMenuButton<int>(
            icon: CircleAvatar(
              backgroundColor: Colors.blue.shade100,
              child: Text(
                user.name[0].toUpperCase(),
                style: TextStyle(color: Colors.blue.shade800),
              ),
            ),
            onSelected: (value) {
              if (value == 2) auth.logout();
            },
            itemBuilder: (context) => [
              PopupMenuItem<int>(
                value: 0,
                enabled: false,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user.name,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text(user.email,
                        style: TextStyle(
                            fontSize: 12, color: Colors.grey.shade600)),
                  ],
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem<int>(
                value: 1,
                child: Row(
                  children: [
                    Icon(Icons.settings, color: Colors.grey),
                    SizedBox(width: 8),
                    Text('Paramètres'),
                  ],
                ),
              ),
              const PopupMenuItem<int>(
                value: 2,
                child: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.red),
                    SizedBox(width: 8),
                    Text('Déconnexion', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),

      body: IndexedStack(
        index: _currentTabIndex,
        children: [
          _buildOrdersTab(),
          _buildCreateOrderTab(),
        ],
      ),

      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentTabIndex,
        onTap: _onTabChanged,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey.shade600,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_bag),
            label: 'Mes commandes',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_box),
            label: 'Nouvelle commande',
          ),
        ],
      ),
    );
  }

  // ---------------- ORDERS TAB ----------------
  Widget _buildOrdersTab() {
    return RefreshIndicator(
      onRefresh: _loadOrders,
      child: Consumer<OrderProvider>(
        builder: (context, orders, _) {
          if (orders.isLoading && orders.orders.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          if (orders.orders.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.inbox, size: 80, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('Aucune commande pour l’instant',
                      style: TextStyle(fontSize: 18, color: Colors.grey)),
                  SizedBox(height: 8),
                  Text('Créez votre première commande pour commencer',
                      style: TextStyle(color: Colors.grey)),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: orders.orders.length,
            itemBuilder: (context, index) {
              final order = orders.orders[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 4,
                shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                          builder: (_) => OrderDetailsScreen(order: order)),
                    );
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Header
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(order.id,
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16)),
                            _buildStatusBadge(order.status),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(order.pressingName,
                            style: TextStyle(color: Colors.grey.shade700)),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 4,
                          children: order.services.take(3).map((service) {
                            return Chip(
                              label: Text('${service.name} (${service.quantity})',
                                  style: const TextStyle(fontSize: 12)),
                              backgroundColor: Colors.blue.shade50,
                            );
                          }).toList(),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${order.total.toStringAsFixed(0)} FCFA',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 16, color: Colors.blue)),
                            Text(
                                DateFormat('dd/MM/yyyy HH:mm')
                                    .format(order.createdAt),
                                style: TextStyle(
                                    fontSize: 12, color: Colors.grey.shade600)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // ---------------- CREATE ORDER TAB ----------------
  Widget _buildCreateOrderTab() {
    return Center(
      child: ElevatedButton.icon(
        onPressed: () {
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const CreateOrderScreen()))
              .then((_) => _loadOrders());
        },
        icon: const Icon(Icons.add),
        label: const Text('Créer une commande'),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }

  // ---------------- STATUS BADGE ----------------
  Widget _buildStatusBadge(String status) {
    Color color;
    String label;
    IconData icon;

    switch (status) {
      case 'pending':
        color = Colors.orange;
        label = 'En attente';
        icon = Icons.schedule;
        break;
      case 'in_progress':
        color = Colors.blue;
        label = 'En cours';
        icon = Icons.autorenew;
        break;
      case 'ready':
        color = Colors.green;
        label = 'Prête';
        icon = Icons.check_circle;
        break;
      case 'delivered':
        color = Colors.grey;
        label = 'Livrée';
        icon = Icons.done_all;
        break;
      default:
        color = Colors.grey;
        label = status;
        icon = Icons.help;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }
}
