/// Modèle Paiement
class Payment {
  final String id;
  final String orderId;
  final double amount;
  final String method; // 'cash', 'card', 'mobile_money'
  final String status; // 'pending', 'paid', 'refunded'
  final DateTime? paidAt;
  final String? transactionId;
  final String? phoneNumber; // Pour Mobile Money

  Payment({
    required this.id,
    required this.orderId,
    required this.amount,
    required this.method,
    required this.status,
    this.paidAt,
    this.transactionId,
    this.phoneNumber,
  });

  /// Conversion depuis JSON
  factory Payment.fromJson(Map<String, dynamic> json) {
    return Payment(
      id: json['id'],
      orderId: json['orderId'],
      amount: json['amount'].toDouble(),
      method: json['method'],
      status: json['status'],
      paidAt: json['paidAt'] != null
          ? DateTime.parse(json['paidAt'])
          : null,
      transactionId: json['transactionId'],
      phoneNumber: json['phoneNumber'],
    );
  }

  /// Conversion vers JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'orderId': orderId,
      'amount': amount,
      'method': method,
      'status': status,
      'paidAt': paidAt?.toIso8601String(),
      'transactionId': transactionId,
      'phoneNumber': phoneNumber,
    };
  }

  /// Vérifie si le paiement est validé
  bool get isPaid => status == 'paid';

  /// Retourne le label du moyen de paiement
  String get methodLabel {
    switch (method) {
      case 'cash':
        return 'Espèces';
      case 'card':
        return 'Carte bancaire';
      case 'mobile_money':
        return 'Mobile Money';
      default:
        return method;
    }
  }

  /// Retourne le label du statut
  String get statusLabel {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'paid':
        return 'Payé';
      case 'refunded':
        return 'Remboursé';
      default:
        return status;
    }
  }

  /// Copie avec modifications
  Payment copyWith({
    String? status,
    DateTime? paidAt,
    String? transactionId,
  }) {
    return Payment(
      id: id,
      orderId: orderId,
      amount: amount,
      method: method,
      status: status ?? this.status,
      paidAt: paidAt ?? this.paidAt,
      transactionId: transactionId ?? this.transactionId,
      phoneNumber: phoneNumber,
    );
  }
}