/// Modèle Utilisateur
/// Rôles: admin, manager, employee, client
class User {
  final String id;
  final String name;
  final String email;
  final String role; // 'admin', 'manager', 'employee', 'client'
  final String? pressingId; // ID du pressing (pour manager/employee)
  final String? phone;
  final String? avatar;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    this.pressingId,
    this.phone,
    this.avatar,
  });

  /// Conversion depuis JSON (pour stockage)
  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'],
      name: json['name'],
      email: json['email'],
      role: json['role'],
      pressingId: json['pressingId'],
      phone: json['phone'],
      avatar: json['avatar'],
    );
  }

  /// Conversion vers JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'role': role,
      'pressingId': pressingId,
      'phone': phone,
      'avatar': avatar,
    };
  }

  /// Vérifie si l'utilisateur est admin
  bool get isAdmin => role == 'admin';

  /// Vérifie si l'utilisateur est manager
  bool get isManager => role == 'manager';

  /// Vérifie si l'utilisateur est employé
  bool get isEmployee => role == 'employee';

  /// Vérifie si l'utilisateur est client
  bool get isClient => role == 'client';
}

/// Modèle Pressing (établissement)
class Pressing {
  final String id;
  final String name;
  final String address;
  final String phone;
  final String? logo;
  final String managerId;

  Pressing({
    required this.id,
    required this.name,
    required this.address,
    required this.phone,
    this.logo,
    required this.managerId,
  });

  factory Pressing.fromJson(Map<String, dynamic> json) {
    return Pressing(
      id: json['id'],
      name: json['name'],
      address: json['address'],
      phone: json['phone'],
      logo: json['logo'],
      managerId: json['managerId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'address': address,
      'phone': phone,
      'logo': logo,
      'managerId': managerId,
    };
  }
}