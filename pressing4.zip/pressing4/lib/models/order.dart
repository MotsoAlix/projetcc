import 'payment.dart';

/// Modèle Commande
class Order {
  final String id;
  final String clientId;
  final String clientName;
  final String pressingId;
  final String pressingName;
  final List<ServiceItem> services;
  final List<String> photoUrls; // URLs base64 des photos
  final String status; // 'pending', 'in_progress', 'ready', 'delivered', 'cancelled'
  final double total;
  final Payment? payment;
  final DateTime createdAt;
  final DateTime? readyAt;
  final DateTime? deliveredAt;
  final String? notes;

  Order({
    required this.id,
    required this.clientId,
    required this.clientName,
    required this.pressingId,
    required this.pressingName,
    required this.services,
    this.photoUrls = const [],
    required this.status,
    required this.total,
    this.payment,
    required this.createdAt,
    this.readyAt,
    this.deliveredAt,
    this.notes,
  });

  /// Conversion depuis JSON
  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'],
      clientId: json['clientId'],
      clientName: json['clientName'],
      pressingId: json['pressingId'],
      pressingName: json['pressingName'],
      services: (json['services'] as List)
          .map((s) => ServiceItem.fromJson(s))
          .toList(),
      photoUrls: List<String>.from(json['photoUrls'] ?? []),
      status: json['status'],
      total: json['total'].toDouble(),
      payment: json['payment'] != null
          ? Payment.fromJson(json['payment'])
          : null,
      createdAt: DateTime.parse(json['createdAt']),
      readyAt: json['readyAt'] != null
          ? DateTime.parse(json['readyAt'])
          : null,
      deliveredAt: json['deliveredAt'] != null
          ? DateTime.parse(json['deliveredAt'])
          : null,
      notes: json['notes'],
    );
  }

  /// Conversion vers JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'clientId': clientId,
      'clientName': clientName,
      'pressingId': pressingId,
      'pressingName': pressingName,
      'services': services.map((s) => s.toJson()).toList(),
      'photoUrls': photoUrls,
      'status': status,
      'total': total,
      'payment': payment?.toJson(),
      'createdAt': createdAt.toIso8601String(),
      'readyAt': readyAt?.toIso8601String(),
      'deliveredAt': deliveredAt?.toIso8601String(),
      'notes': notes,
    };
  }

  /// Retourne le statut en français
  String get statusLabel {
    switch (status) {
      case 'pending':
        return 'En attente';
      case 'in_progress':
        return 'En cours';
      case 'ready':
        return 'Prête';
      case 'delivered':
        return 'Livrée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  }

  /// Vérifie si la commande est payée
  bool get isPaid => payment?.isPaid ?? false;

  /// Copie avec modifications
  Order copyWith({
    String? status,
    Payment? payment,
    DateTime? readyAt,
    DateTime? deliveredAt,
  }) {
    return Order(
      id: id,
      clientId: clientId,
      clientName: clientName,
      pressingId: pressingId,
      pressingName: pressingName,
      services: services,
      photoUrls: photoUrls,
      status: status ?? this.status,
      total: total,
      payment: payment ?? this.payment,
      createdAt: createdAt,
      readyAt: readyAt ?? this.readyAt,
      deliveredAt: deliveredAt ?? this.deliveredAt,
      notes: notes,
    );
  }
}

/// Service individuel dans une commande
class ServiceItem {
  final String id;
  final String name;
  final int quantity;
  final double price;

  ServiceItem({
    required this.id,
    required this.name,
    required this.quantity,
    required this.price,
  });

  double get subtotal => quantity * price;

  factory ServiceItem.fromJson(Map<String, dynamic> json) {
    return ServiceItem(
      id: json['id'],
      name: json['name'],
      quantity: json['quantity'],
      price: json['price'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'quantity': quantity,
      'price': price,
    };
  }
}

/// Services disponibles dans le pressing
class AvailableService {
  final String id;
  final String name;
  final double price;
  final String? description;
  final String? icon;

  AvailableService({
    required this.id,
    required this.name,
    required this.price,
    this.description,
    this.icon,
  });

  static List<AvailableService> defaults = [
    AvailableService(
      id: 'dry_clean',
      name: 'Nettoyage à sec',
      price: 5000,
      description: 'Nettoyage professionnel à sec',
      icon: '🧥',
    ),
    AvailableService(
      id: 'ironing',
      name: 'Repassage',
      price: 2000,
      description: 'Repassage soigné',
      icon: '👔',
    ),
    AvailableService(
      id: 'stain_removal',
      name: 'Détachage',
      price: 3000,
      description: 'Traitement des taches tenaces',
      icon: '🧼',
    ),
    AvailableService(
      id: 'express',
      name: 'Service Express',
      price: 10000,
      description: 'Traitement en 24h',
      icon: '⚡',
    ),
    AvailableService(
      id: 'alterations',
      name: 'Retouches',
      price: 4000,
      description: 'Retouches et réparations',
      icon: '✂️',
    ),
  ];
}