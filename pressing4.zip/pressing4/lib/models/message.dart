/// Modèle Message (pour le chat)
class Message {
  final String id;
  final String orderId;
  final String senderId;
  final String senderName;
  final String senderRole; // 'client', 'employee', 'manager'
  final String text;
  final DateTime sentAt;
  final bool isRead;

  Message({
    required this.id,
    required this.orderId,
    required this.senderId,
    required this.senderName,
    required this.senderRole,
    required this.text,
    required this.sentAt,
    this.isRead = false,
  });

  /// Conversion depuis JSON
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      orderId: json['orderId'],
      senderId: json['senderId'],
      senderName: json['senderName'],
      senderRole: json['senderRole'],
      text: json['text'],
      sentAt: DateTime.parse(json['sentAt']),
      isRead: json['isRead'] ?? false,
    );
  }

  /// Conversion vers JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'orderId': orderId,
      'senderId': senderId,
      'senderName': senderName,
      'senderRole': senderRole,
      'text': text,
      'sentAt': sentAt.toIso8601String(),
      'isRead': isRead,
    };
  }

  /// Vérifie si le message vient d'un client
  bool get isFromClient => senderRole == 'client';

  /// Copie avec modifications
  Message copyWith({
    bool? isRead,
  }) {
    return Message(
      id: id,
      orderId: orderId,
      senderId: senderId,
      senderName: senderName,
      senderRole: senderRole,
      text: text,
      sentAt: sentAt,
      isRead: isRead ?? this.isRead,
    );
  }
}

/// Modèle Notification
class AppNotification {
  final String id;
  final String userId;
  final String title;
  final String message;
  final String type; // 'order_update', 'payment', 'chat', 'system'
  final DateTime createdAt;
  final bool isRead;
  final String? orderId; // Lien vers une commande

  AppNotification({
    required this.id,
    required this.userId,
    required this.title,
    required this.message,
    required this.type,
    required this.createdAt,
    this.isRead = false,
    this.orderId,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: json['id'],
      userId: json['userId'],
      title: json['title'],
      message: json['message'],
      type: json['type'],
      createdAt: DateTime.parse(json['createdAt']),
      isRead: json['isRead'] ?? false,
      orderId: json['orderId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'userId': userId,
      'title': title,
      'message': message,
      'type': type,
      'createdAt': createdAt.toIso8601String(),
      'isRead': isRead,
      'orderId': orderId,
    };
  }

  AppNotification copyWith({bool? isRead}) {
    return AppNotification(
      id: id,
      userId: userId,
      title: title,
      message: message,
      type: type,
      createdAt: createdAt,
      isRead: isRead ?? this.isRead,
      orderId: orderId,
    );
  }
}