package com.pressing.repository;

import com.pressing.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MessageRepository extends JpaRepository<Message, String> {
    
    List<Message> findByConversationIdOrderBySentAtAsc(String conversationId);
    
    @Query("SELECT m FROM Message m WHERE m.conversation.id = :conversationId AND m.sender.id != :userId AND m.readAt IS NULL")
    List<Message> findUnreadMessagesByConversationIdAndUserId(@Param("conversationId") String conversationId, @Param("userId") String userId);
    
    @Modifying
    @Query("UPDATE Message m SET m.readAt = :readAt WHERE m.conversation.id = :conversationId AND m.sender.id != :userId AND m.readAt IS NULL")
    void markAllAsReadInConversation(@Param("conversationId") String conversationId, @Param("userId") String userId, @Param("readAt") LocalDateTime readAt);
    
    Long countByConversationIdAndSenderIdNotAndReadAtIsNull(String conversationId, String senderId);
}
