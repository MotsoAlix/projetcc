package com.pressing.repository;

import com.pressing.entity.Order;
import com.pressing.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, String> {
    
    List<Order> findByClientIdOrderByCreatedAtDesc(String clientId);
    
    List<Order> findByEmployeeIdOrderByCreatedAtDesc(String employeeId);
    
    List<Order> findByStatusOrderByCreatedAtDesc(OrderStatus status);
    
    List<Order> findByStatusInOrderByCreatedAtDesc(List<OrderStatus> statuses);
    
    @Query("SELECT o FROM Order o WHERE o.client.id = :clientId AND o.status IN :statuses ORDER BY o.createdAt DESC")
    List<Order> findByClientIdAndStatusIn(@Param("clientId") String clientId, @Param("statuses") List<OrderStatus> statuses);
    
    @Query("SELECT COUNT(o) FROM Order o WHERE o.status = :status")
    Long countByStatus(@Param("status") OrderStatus status);
    
    @Query("SELECT COUNT(o) FROM Order o WHERE o.createdAt >= :startOfDay")
    Long countByCreatedAtAfter(@Param("startOfDay") LocalDateTime startOfDay);
    
    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.isPaid = true")
    Double sumTotalAmountByIsPaidTrue();
    
    @Query("SELECT SUM(o.totalAmount) FROM Order o WHERE o.isPaid = true AND o.createdAt >= :startOfDay")
    Double sumTotalAmountByIsPaidTrueAndCreatedAtAfter(@Param("startOfDay") LocalDateTime startOfDay);
    
    boolean existsByOrderNumber(String orderNumber);
}
