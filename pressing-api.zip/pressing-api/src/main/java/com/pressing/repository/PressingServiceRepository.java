package com.pressing.repository;

import com.pressing.entity.PressingService;
import com.pressing.enums.ServiceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PressingServiceRepository extends JpaRepository<PressingService, String> {
    
    Optional<PressingService> findByType(ServiceType type);
    
    List<PressingService> findByIsActiveTrue();
    
    boolean existsByType(ServiceType type);
}
