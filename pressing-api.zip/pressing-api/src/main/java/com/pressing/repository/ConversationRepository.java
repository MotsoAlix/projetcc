package com.pressing.repository;

import com.pressing.entity.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ConversationRepository extends JpaRepository<Conversation, String> {
    
    List<Conversation> findByParticipantIdOrderByUpdatedAtDesc(String participantId);
    
    Optional<Conversation> findByOrderId(String orderId);
    
    boolean existsByOrderId(String orderId);
    
    @Query("SELECT c FROM Conversation c JOIN c.messages m WHERE m.sender.id = :userId GROUP BY c ORDER BY c.updatedAt DESC")
    List<Conversation> findConversationsByUserId(@Param("userId") String userId);
    
    @Query("SELECT COUNT(c) FROM Conversation c JOIN c.messages m WHERE c.participant.id = :userId AND m.readAt IS NULL AND m.sender.id != :userId")
    Long countUnreadMessagesByParticipantId(@Param("userId") String userId);
}
