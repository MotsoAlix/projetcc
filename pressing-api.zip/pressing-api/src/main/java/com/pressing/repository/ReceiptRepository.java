package com.pressing.repository;

import com.pressing.entity.Receipt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReceiptRepository extends JpaRepository<Receipt, String> {
    
    List<Receipt> findByClientIdOrderByIssueDateDesc(String clientId);
    
    Optional<Receipt> findByOrderId(String orderId);
    
    Optional<Receipt> findByReceiptNumber(String receiptNumber);
    
    boolean existsByReceiptNumber(String receiptNumber);
    
    List<Receipt> findByIsPaidFalseOrderByIssueDateDesc();
    
    @Query("SELECT COUNT(r) FROM Receipt r WHERE r.isPaid = true")
    Long countByIsPaidTrue();
    
    @Query("SELECT COUNT(r) FROM Receipt r WHERE r.isPaid = false")
    Long countByIsPaidFalse();
    
    @Query("SELECT SUM(r.totalAmount) FROM Receipt r WHERE r.isPaid = true")
    Double sumTotalAmountByIsPaidTrue();
    
    @Query("SELECT SUM(r.amountDue) FROM Receipt r WHERE r.isPaid = false")
    Double sumAmountDueByIsPaidFalse();
    
    @Query("SELECT r FROM Receipt r WHERE r.client.id = :clientId AND r.isPaid = false ORDER BY r.issueDate DESC")
    List<Receipt> findUnpaidByClientId(@Param("clientId") String clientId);
}
