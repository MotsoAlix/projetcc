package com.pressing.service;

import com.pressing.dto.ConversationDTO;
import com.pressing.dto.MessageDTO;
import com.pressing.dto.SendMessageRequest;
import com.pressing.entity.Conversation;
import com.pressing.entity.Message;
import com.pressing.entity.Order;
import com.pressing.entity.User;
import com.pressing.repository.ConversationRepository;
import com.pressing.repository.MessageRepository;
import com.pressing.repository.OrderRepository;
import com.pressing.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ChatService {

    @Autowired
    private ConversationRepository conversationRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    @Transactional(readOnly = true)
    public List<ConversationDTO> getUserConversations(String userId) {
        return conversationRepository.findByParticipantIdOrderByUpdatedAtDesc(userId).stream()
                .map(c -> mapToDTO(c, userId))
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ConversationDTO getConversation(String conversationId, String userId) {
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new RuntimeException("Conversation non trouvée"));
        return mapToDTO(conversation, userId);
    }

    @Transactional(readOnly = true)
    public List<MessageDTO> getConversationMessages(String conversationId) {
        return messageRepository.findByConversationIdOrderBySentAtAsc(conversationId).stream()
                .map(this::mapMessageToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public MessageDTO sendMessage(String conversationId, String senderId, SendMessageRequest request) {
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new RuntimeException("Conversation non trouvée"));

        User sender = userRepository.findById(senderId)
                .orElseThrow(() -> new RuntimeException("Expéditeur non trouvé"));

        Message message = Message.builder()
                .conversation(conversation)
                .sender(sender)
                .content(request.getContent())
                .attachments(request.getAttachments() != null ? request.getAttachments() : new java.util.ArrayList<>())
                .isSystem(false)
                .build();

        conversation.addMessage(message);
        messageRepository.save(message);
        conversationRepository.save(conversation);

        // Create notification for recipient
        User recipient = conversation.getParticipant();
        if (!recipient.getId().equals(senderId)) {
            notificationService.createMessageNotification(
                recipient, 
                sender.getFullName(), 
                conversation.getOrderNumber()
            );
        }

        return mapMessageToDTO(message);
    }

    @Transactional
    public void markAllAsRead(String conversationId, String userId) {
        messageRepository.markAllAsReadInConversation(conversationId, userId, LocalDateTime.now());
    }

    @Transactional
    public ConversationDTO getOrCreateConversationForOrder(String orderId, String participantId) {
        // Check if conversation already exists
        Conversation existing = conversationRepository.findByOrderId(orderId).orElse(null);
        if (existing != null) {
            return mapToDTO(existing, participantId);
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));

        User participant = userRepository.findById(participantId)
                .orElseThrow(() -> new RuntimeException("Participant non trouvé"));

        Conversation conversation = Conversation.builder()
                .participant(participant)
                .order(order)
                .build();

        conversationRepository.save(conversation);
        return mapToDTO(conversation, participantId);
    }

    @Transactional(readOnly = true)
    public int getUnreadCount(String userId) {
        return conversationRepository.countUnreadMessagesByParticipantId(userId).intValue();
    }

    public ConversationDTO mapToDTO(Conversation conversation, String currentUserId) {
        if (conversation == null) return null;

        Message lastMessage = conversation.getLastMessage();

        return ConversationDTO.builder()
                .id(conversation.getId())
                .participantId(conversation.getParticipant() != null ? conversation.getParticipant().getId() : null)
                .participantName(conversation.getParticipant() != null ? conversation.getParticipant().getFullName() : null)
                .participantAvatar(conversation.getParticipant() != null ? conversation.getParticipant().getAvatarUrl() : null)
                .orderId(conversation.getOrder() != null ? conversation.getOrder().getId() : null)
                .orderNumber(conversation.getOrderNumber())
                .messages(conversation.getMessages().stream()
                        .map(this::mapMessageToDTO)
                        .collect(Collectors.toList()))
                .createdAt(conversation.getCreatedAt())
                .updatedAt(conversation.getUpdatedAt())
                .isArchived(conversation.getIsArchived())
                .unreadCount(conversation.getUnreadCount(currentUserId))
                .lastMessagePreview(lastMessage != null ? 
                        (lastMessage.getContent().length() > 40 ? 
                                lastMessage.getContent().substring(0, 40) + "..." : 
                                lastMessage.getContent()) : 
                        "Aucun message")
                .lastMessageTime(lastMessage != null ? lastMessage.getSentAt() : null)
                .build();
    }

    private MessageDTO mapMessageToDTO(Message message) {
        if (message == null) return null;

        return MessageDTO.builder()
                .id(message.getId())
                .conversationId(message.getConversation() != null ? message.getConversation().getId() : null)
                .senderId(message.getSender() != null ? message.getSender().getId() : null)
                .senderName(message.getSender() != null ? message.getSender().getFullName() : null)
                .senderAvatar(message.getSender() != null ? message.getSender().getAvatarUrl() : null)
                .content(message.getContent())
                .sentAt(message.getSentAt())
                .readAt(message.getReadAt())
                .attachments(message.getAttachments())
                .isSystem(message.getIsSystem())
                .build();
    }
}
