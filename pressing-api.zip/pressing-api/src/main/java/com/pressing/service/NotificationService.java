package com.pressing.service;

import com.pressing.dto.NotificationDTO;
import com.pressing.entity.Notification;
import com.pressing.entity.Order;
import com.pressing.entity.User;
import com.pressing.enums.NotificationType;
import com.pressing.enums.OrderStatus;
import com.pressing.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Transactional(readOnly = true)
    public List<NotificationDTO> getUserNotifications(String userId) {
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<NotificationDTO> getUnreadNotifications(String userId) {
        return notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public Long getUnreadCount(String userId) {
        return notificationRepository.countByUserIdAndIsReadFalse(userId);
    }

    @Transactional
    public void markAsRead(String notificationId) {
        notificationRepository.markAsRead(notificationId, java.time.LocalDateTime.now());
    }

    @Transactional
    public void markAllAsRead(String userId) {
        notificationRepository.markAllAsReadByUserId(userId, java.time.LocalDateTime.now());
    }

    @Transactional
    public void deleteNotification(String notificationId) {
        notificationRepository.deleteById(notificationId);
    }

    @Transactional
    public void createOrderNotification(User user, Order order) {
        Notification notification = Notification.builder()
                .user(user)
                .type(NotificationType.ORDER_CREATED)
                .title("Nouvelle commande")
                .body("Votre commande " + order.getOrderNumber() + " a été créée avec succès.")
                .relatedId(order.getId())
                .isRead(false)
                .build();
        
        notificationRepository.save(notification);
    }

    @Transactional
    public void createOrderStatusNotification(User user, Order order, OrderStatus oldStatus, OrderStatus newStatus) {
        String title;
        String body;

        switch (newStatus) {
            case RECEIVED:
                title = "Commande reçue";
                body = "Votre commande " + order.getOrderNumber() + " a été reçue.";
                break;
            case IN_PROGRESS:
                title = "Commande en traitement";
                body = "Votre commande " + order.getOrderNumber() + " est en cours de traitement.";
                break;
            case READY:
                title = "Commande prête !";
                body = "Votre commande " + order.getOrderNumber() + " est prête à être récupérée.";
                break;
            case DELIVERED:
                title = "Commande livrée";
                body = "Votre commande " + order.getOrderNumber() + " a été livrée.";
                break;
            case CANCELLED:
                title = "Commande annulée";
                body = "Votre commande " + order.getOrderNumber() + " a été annulée.";
                break;
            default:
                title = "Statut mis à jour";
                body = "Le statut de votre commande " + order.getOrderNumber() + " a été mis à jour.";
        }

        Notification notification = Notification.builder()
                .user(user)
                .type(newStatus == OrderStatus.READY ? NotificationType.ORDER_READY : NotificationType.ORDER_STATUS_CHANGED)
                .title(title)
                .body(body)
                .relatedId(order.getId())
                .isRead(false)
                .build();
        
        notificationRepository.save(notification);
    }

    @Transactional
    public void createPaymentNotification(User user, Order order) {
        Notification notification = Notification.builder()
                .user(user)
                .type(NotificationType.PAYMENT_RECEIVED)
                .title("Paiement confirmé")
                .body(String.format("Votre paiement de %.2f € pour la commande %s a été reçu.", 
                        order.getTotalAmount(), order.getOrderNumber()))
                .relatedId(order.getId())
                .isRead(false)
                .build();
        
        notificationRepository.save(notification);
    }

    @Transactional
    public void createMessageNotification(User user, String senderName, String orderNumber) {
        Notification notification = Notification.builder()
                .user(user)
                .type(NotificationType.MESSAGE_RECEIVED)
                .title("Nouveau message")
                .body(senderName + " vous a envoyé un message" + 
                        (orderNumber != null ? " concernant la commande " + orderNumber : "") + ".")
                .isRead(false)
                .build();
        
        notificationRepository.save(notification);
    }

    public NotificationDTO mapToDTO(Notification notification) {
        if (notification == null) return null;

        return NotificationDTO.builder()
                .id(notification.getId())
                .userId(notification.getUser() != null ? notification.getUser().getId() : null)
                .type(notification.getType())
                .title(notification.getTitle())
                .body(notification.getBody())
                .imageUrl(notification.getImageUrl())
                .actionUrl(notification.getActionUrl())
                .relatedId(notification.getRelatedId())
                .isRead(notification.getIsRead())
                .createdAt(notification.getCreatedAt())
                .readAt(notification.getReadAt())
                .build();
    }
}
