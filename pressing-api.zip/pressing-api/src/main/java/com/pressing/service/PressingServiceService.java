package com.pressing.service;

import com.pressing.dto.PressingServiceDTO;
import com.pressing.entity.PressingService;
import com.pressing.enums.ServiceType;
import com.pressing.repository.PressingServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PressingServiceService {

    @Autowired
    private PressingServiceRepository serviceRepository;

    @Transactional(readOnly = true)
    public List<PressingServiceDTO> getAllServices() {
        return serviceRepository.findByIsActiveTrue().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PressingServiceDTO getServiceById(String id) {
        PressingService service = serviceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Service non trouvé"));
        return mapToDTO(service);
    }

    @Transactional(readOnly = true)
    public PressingServiceDTO getServiceByType(ServiceType type) {
        PressingService service = serviceRepository.findByType(type)
                .orElseThrow(() -> new RuntimeException("Service non trouvé"));
        return mapToDTO(service);
    }

    @Transactional
    public void initializeDefaultServices() {
        if (serviceRepository.count() > 0) {
            return;
        }

        Arrays.stream(ServiceType.values()).forEach(type -> {
            PressingService service = PressingService.builder()
                    .type(type)
                    .name(type.getDisplayName())
                    .description(getServiceDescription(type))
                    .basePrice(type.getBasePrice())
                    .pricePerUnit(0.0)
                    .unit("pièce")
                    .estimatedDurationHours(type.getEstimatedDurationHours())
                    .isActive(true)
                    .build();
            
            serviceRepository.save(service);
        });
    }

    private String getServiceDescription(ServiceType type) {
        return switch (type) {
            case WASHING -> "Lavage en machine avec détergent de qualité";
            case DRY_CLEANING -> "Nettoyage professionnel à sec pour vêtements délicats";
            case IRONING -> "Repassage professionnel avec finition vapeur";
            case STAIN_REMOVAL -> "Traitement des taches tenaces par nos experts";
            case REPAIR -> "Ourlet, couture, réparation de boutons";
            case LEATHER_CARE -> "Nettoyage et nourrissage du cuir";
            case WEDDING_DRESS -> "Nettoyage spécialisé robe de mariée avec conservation";
            case DUVET -> "Nettoyage de couettes et duvets";
            case CARPET -> "Nettoyage professionnel de tapis";
        };
    }

    public PressingServiceDTO mapToDTO(PressingService service) {
        if (service == null) return null;

        return PressingServiceDTO.builder()
                .id(service.getId())
                .type(service.getType())
                .name(service.getName())
                .description(service.getDescription())
                .basePrice(service.getBasePrice())
                .pricePerUnit(service.getPricePerUnit())
                .unit(service.getUnit())
                .estimatedDurationHours(service.getEstimatedDurationHours())
                .isActive(service.getIsActive())
                .iconUrl(service.getIconUrl())
                .build();
    }
}
