package com.pressing.service;

import com.pressing.dto.*;
import com.pressing.entity.Order;
import com.pressing.entity.OrderItem;
import com.pressing.entity.PressingService;
import com.pressing.entity.User;
import com.pressing.enums.OrderStatus;
import com.pressing.repository.OrderRepository;
import com.pressing.repository.PressingServiceRepository;
import com.pressing.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PressingServiceRepository serviceRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    @Transactional(readOnly = true)
    public List<OrderDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderDTO> getOrdersByClient(String clientId) {
        return orderRepository.findByClientIdOrderByCreatedAtDesc(clientId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public OrderDTO getOrderById(String id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));
        return mapToDTO(order);
    }

    @Transactional(readOnly = true)
    public OrderDTO getOrderByNumber(String orderNumber) {
        Order order = orderRepository.findAll().stream()
                .filter(o -> o.getOrderNumber().equals(orderNumber))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));
        return mapToDTO(order);
    }

    @Transactional
    public OrderDTO createOrder(CreateOrderRequest request, String employeeId) {
        User client = userRepository.findById(request.getClientId())
                .orElseThrow(() -> new RuntimeException("Client non trouvé"));

        User employee = null;
        if (employeeId != null) {
            employee = userRepository.findById(employeeId).orElse(null);
        }

        Order order = Order.builder()
                .orderNumber(generateOrderNumber())
                .client(client)
                .employee(employee)
                .status(OrderStatus.PENDING)
                .totalAmount(0.0)
                .notes(request.getNotes())
                .deliveryAddress(request.getDeliveryAddress())
                .isDelivery(request.getIsDelivery() != null ? request.getIsDelivery() : false)
                .isPaid(false)
                .estimatedReadyAt(request.getEstimatedReadyAt())
                .build();

        // Add items
        for (OrderItemRequest itemRequest : request.getItems()) {
            PressingService service = serviceRepository.findById(itemRequest.getServiceId())
                    .orElseThrow(() -> new RuntimeException("Service non trouvé"));

            OrderItem item = OrderItem.builder()
                    .service(service)
                    .quantity(itemRequest.getQuantity())
                    .notes(itemRequest.getNotes())
                    .unitPrice(service.getBasePrice())
                    .build();

            order.addItem(item);
        }

        orderRepository.save(order);

        // Create notification for client
        notificationService.createOrderNotification(client, order);

        return mapToDTO(order);
    }

    @Transactional
    public OrderDTO updateOrderStatus(String orderId, OrderStatus newStatus, String userId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));

        OrderStatus oldStatus = order.getStatus();
        order.setStatus(newStatus);

        // Update timestamps based on status
        switch (newStatus) {
            case RECEIVED:
                order.setReceivedAt(LocalDateTime.now());
                break;
            case READY:
                order.setReadyAt(LocalDateTime.now());
                break;
            case DELIVERED:
                order.setDeliveredAt(LocalDateTime.now());
                break;
            default:
                break;
        }

        orderRepository.save(order);

        // Create notification for status change
        notificationService.createOrderStatusNotification(order.getClient(), order, oldStatus, newStatus);

        return mapToDTO(order);
    }

    @Transactional
    public OrderDTO markAsPaid(String orderId, String paymentMethod) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));

        order.setIsPaid(true);
        order.setPaidAt(LocalDateTime.now());
        order.setPaymentMethod(paymentMethod);

        orderRepository.save(order);

        // Create payment notification
        notificationService.createPaymentNotification(order.getClient(), order);

        return mapToDTO(order);
    }

    @Transactional
    public void deleteOrder(String orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));
        orderRepository.delete(order);
    }

    @Transactional(readOnly = true)
    public OrderStatisticsDTO getStatistics() {
        LocalDateTime today = LocalDate.now().atStartOfDay();

        return OrderStatisticsDTO.builder()
                .totalOrders(orderRepository.count())
                .todayOrders(orderRepository.countByCreatedAtAfter(today))
                .pendingOrders(orderRepository.countByStatus(OrderStatus.PENDING))
                .inProgressOrders(orderRepository.countByStatus(OrderStatus.IN_PROGRESS))
                .readyOrders(orderRepository.countByStatus(OrderStatus.READY))
                .deliveredOrders(orderRepository.countByStatus(OrderStatus.DELIVERED))
                .cancelledOrders(orderRepository.countByStatus(OrderStatus.CANCELLED))
                .totalRevenue(orderRepository.sumTotalAmountByIsPaidTrue() != null ? 
                        orderRepository.sumTotalAmountByIsPaidTrue() : 0.0)
                .todayRevenue(orderRepository.sumTotalAmountByIsPaidTrueAndCreatedAtAfter(today) != null ? 
                        orderRepository.sumTotalAmountByIsPaidTrueAndCreatedAtAfter(today) : 0.0)
                .build();
    }

    private String generateOrderNumber() {
        String date = java.time.LocalDate.now().toString().replace("-", "");
        String random = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        return "CMD-" + date + "-" + random;
    }

    public OrderDTO mapToDTO(Order order) {
        if (order == null) return null;

        return OrderDTO.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .clientId(order.getClient() != null ? order.getClient().getId() : null)
                .client(userService.mapToDTO(order.getClient()))
                .employeeId(order.getEmployee() != null ? order.getEmployee().getId() : null)
                .employee(userService.mapToDTO(order.getEmployee()))
                .items(order.getItems().stream()
                        .map(this::mapItemToDTO)
                        .collect(Collectors.toList()))
                .status(order.getStatus())
                .totalAmount(order.getTotalAmount())
                .createdAt(order.getCreatedAt())
                .receivedAt(order.getReceivedAt())
                .readyAt(order.getReadyAt())
                .deliveredAt(order.getDeliveredAt())
                .estimatedReadyAt(order.getEstimatedReadyAt())
                .notes(order.getNotes())
                .deliveryAddress(order.getDeliveryAddress())
                .isDelivery(order.getIsDelivery())
                .isPaid(order.getIsPaid())
                .paidAt(order.getPaidAt())
                .paymentMethod(order.getPaymentMethod())
                .build();
    }

    private OrderItemDTO mapItemToDTO(OrderItem item) {
        if (item == null) return null;

        return OrderItemDTO.builder()
                .id(item.getId())
                .orderId(item.getOrder() != null ? item.getOrder().getId() : null)
                .service(mapServiceToDTO(item.getService()))
                .quantity(item.getQuantity())
                .notes(item.getNotes())
                .photoUrls(item.getPhotoUrls())
                .unitPrice(item.getUnitPrice())
                .build();
    }

    private PressingServiceDTO mapServiceToDTO(PressingService service) {
        if (service == null) return null;

        return PressingServiceDTO.builder()
                .id(service.getId())
                .type(service.getType())
                .name(service.getName())
                .description(service.getDescription())
                .basePrice(service.getBasePrice())
                .pricePerUnit(service.getPricePerUnit())
                .unit(service.getUnit())
                .estimatedDurationHours(service.getEstimatedDurationHours())
                .isActive(service.getIsActive())
                .iconUrl(service.getIconUrl())
                .build();
    }
}
