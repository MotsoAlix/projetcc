package com.pressing.service;

import com.pressing.dto.ReceiptDTO;
import com.pressing.dto.ReceiptItemDTO;
import com.pressing.dto.ReceiptStatisticsDTO;
import com.pressing.entity.Order;
import com.pressing.entity.OrderItem;
import com.pressing.entity.Receipt;
import com.pressing.entity.ReceiptItem;
import com.pressing.repository.OrderRepository;
import com.pressing.repository.ReceiptRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class ReceiptService {

    @Autowired
    private ReceiptRepository receiptRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserService userService;

    @Transactional(readOnly = true)
    public List<ReceiptDTO> getAllReceipts() {
        return receiptRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ReceiptDTO> getReceiptsByClient(String clientId) {
        return receiptRepository.findByClientIdOrderByIssueDateDesc(clientId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ReceiptDTO getReceiptById(String id) {
        Receipt receipt = receiptRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reçu non trouvé"));
        return mapToDTO(receipt);
    }

    @Transactional(readOnly = true)
    public ReceiptDTO getReceiptByOrderId(String orderId) {
        Receipt receipt = receiptRepository.findByOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Reçu non trouvé"));
        return mapToDTO(receipt);
    }

    @Transactional
    public ReceiptDTO generateReceipt(String orderId) {
        // Check if receipt already exists
        Receipt existing = receiptRepository.findByOrderId(orderId).orElse(null);
        if (existing != null) {
            return mapToDTO(existing);
        }

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Commande non trouvée"));

        double taxRate = 20.0;
        double subtotal = order.getTotalAmount();
        double taxAmount = subtotal * taxRate / 100;
        double totalAmount = subtotal + taxAmount;

        Receipt receipt = Receipt.builder()
                .receiptNumber(generateReceiptNumber())
                .order(order)
                .client(order.getClient())
                .clientName(order.getClient().getFullName())
                .clientEmail(order.getClient().getEmail())
                .clientPhone(order.getClient().getPhone())
                .dueDate(LocalDateTime.now().plusDays(30))
                .subtotal(subtotal)
                .taxRate(taxRate)
                .taxAmount(taxAmount)
                .totalAmount(totalAmount)
                .amountPaid(order.getIsPaid() ? totalAmount : 0.0)
                .amountDue(order.getIsPaid() ? 0.0 : totalAmount)
                .isPaid(order.getIsPaid())
                .paymentMethod(order.getPaymentMethod())
                .paymentDate(order.getPaidAt())
                .terms("Paiement à 30 jours")
                .build();

        // Add items
        for (OrderItem orderItem : order.getItems()) {
            ReceiptItem item = ReceiptItem.builder()
                    .description(orderItem.getService().getName() + 
                            (orderItem.getNotes() != null ? " - " + orderItem.getNotes() : ""))
                    .quantity(orderItem.getQuantity())
                    .unitPrice(orderItem.getUnitPrice())
                    .totalPrice(orderItem.getTotalPrice())
                    .build();
            receipt.addItem(item);
        }

        receiptRepository.save(receipt);
        return mapToDTO(receipt);
    }

    @Transactional
    public ReceiptDTO markAsPaid(String receiptId, String paymentMethod, double amount) {
        Receipt receipt = receiptRepository.findById(receiptId)
                .orElseThrow(() -> new RuntimeException("Reçu non trouvé"));

        receipt.markAsPaid(paymentMethod, amount);
        receiptRepository.save(receipt);

        // Update order payment status
        Order order = receipt.getOrder();
        order.setIsPaid(true);
        order.setPaymentMethod(paymentMethod);
        order.setPaidAt(LocalDateTime.now());
        orderRepository.save(order);

        return mapToDTO(receipt);
    }

    @Transactional
    public void deleteReceipt(String receiptId) {
        Receipt receipt = receiptRepository.findById(receiptId)
                .orElseThrow(() -> new RuntimeException("Reçu non trouvé"));
        receiptRepository.delete(receipt);
    }

    @Transactional(readOnly = true)
    public ReceiptStatisticsDTO getStatistics() {
        Double totalRevenue = receiptRepository.sumTotalAmountByIsPaidTrue();
        Double outstandingAmount = receiptRepository.sumAmountDueByIsPaidFalse();

        return ReceiptStatisticsDTO.builder()
                .totalReceipts(receiptRepository.count())
                .paidReceipts(receiptRepository.countByIsPaidTrue())
                .unpaidReceipts(receiptRepository.countByIsPaidFalse())
                .totalRevenue(totalRevenue != null ? totalRevenue : 0.0)
                .outstandingAmount(outstandingAmount != null ? outstandingAmount : 0.0)
                .build();
    }

    private String generateReceiptNumber() {
        String year = String.valueOf(LocalDateTime.now().getYear()).substring(2);
        String random = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        return year + random;
    }

    public ReceiptDTO mapToDTO(Receipt receipt) {
        if (receipt == null) return null;

        return ReceiptDTO.builder()
                .id(receipt.getId())
                .receiptNumber(receipt.getReceiptNumber())
                .orderId(receipt.getOrder() != null ? receipt.getOrder().getId() : null)
                .orderNumber(receipt.getOrder() != null ? receipt.getOrder().getOrderNumber() : null)
                .clientId(receipt.getClient() != null ? receipt.getClient().getId() : null)
                .clientName(receipt.getClientName())
                .clientAddress(receipt.getClientAddress())
                .clientEmail(receipt.getClientEmail())
                .clientPhone(receipt.getClientPhone())
                .issueDate(receipt.getIssueDate())
                .dueDate(receipt.getDueDate())
                .items(receipt.getItems().stream()
                        .map(this::mapItemToDTO)
                        .collect(Collectors.toList()))
                .subtotal(receipt.getSubtotal())
                .taxRate(receipt.getTaxRate())
                .taxAmount(receipt.getTaxAmount())
                .totalAmount(receipt.getTotalAmount())
                .amountPaid(receipt.getAmountPaid())
                .amountDue(receipt.getAmountDue())
                .paymentMethod(receipt.getPaymentMethod())
                .paymentDate(receipt.getPaymentDate())
                .isPaid(receipt.getIsPaid())
                .notes(receipt.getNotes())
                .terms(receipt.getTerms())
                .pdfUrl(receipt.getPdfUrl())
                .build();
    }

    private ReceiptItemDTO mapItemToDTO(ReceiptItem item) {
        if (item == null) return null;

        return ReceiptItemDTO.builder()
                .id(item.getId())
                .description(item.getDescription())
                .quantity(item.getQuantity())
                .unitPrice(item.getUnitPrice())
                .totalPrice(item.getTotalPrice())
                .build();
    }
}
