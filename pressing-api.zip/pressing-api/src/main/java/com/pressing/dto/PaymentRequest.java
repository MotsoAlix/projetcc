package com.pressing.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PaymentRequest {
    
    @NotBlank(message = "Le mode de paiement est requis")
    private String paymentMethod;
}
