package com.pressing.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConversationDTO {
    private String id;
    private String participantId;
    private String participantName;
    private String participantAvatar;
    private String orderId;
    private String orderNumber;
    @Builder.Default
    private List<MessageDTO> messages = new ArrayList<>();
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Boolean isArchived;
    private int unreadCount;
    private String lastMessagePreview;
    private LocalDateTime lastMessageTime;
}
