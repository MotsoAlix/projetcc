package com.pressing.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReceiptDTO {
    private String id;
    private String receiptNumber;
    private String orderId;
    private String orderNumber;
    private String clientId;
    private String clientName;
    private String clientAddress;
    private String clientEmail;
    private String clientPhone;
    private LocalDateTime issueDate;
    private LocalDateTime dueDate;
    @Builder.Default
    private List<ReceiptItemDTO> items = new ArrayList<>();
    private Double subtotal;
    private Double taxRate;
    private Double taxAmount;
    private Double totalAmount;
    private Double amountPaid;
    private Double amountDue;
    private String paymentMethod;
    private LocalDateTime paymentDate;
    private Boolean isPaid;
    private String notes;
    private String terms;
    private String pdfUrl;
    
    @Transient
    public String getFormattedNumber() {
        return "FAC-" + receiptNumber;
    }
    
    @Transient
    public String getFormattedTotal() {
        return String.format("%.2f €", totalAmount);
    }
    
    @Transient
    public String getPaymentStatus() {
        return isPaid ? "Payée" : "En attente";
    }
}
