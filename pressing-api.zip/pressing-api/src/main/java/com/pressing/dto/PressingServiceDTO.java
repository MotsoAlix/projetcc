package com.pressing.dto;

import com.pressing.enums.ServiceType;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PressingServiceDTO {
    private String id;
    private ServiceType type;
    private String name;
    private String description;
    private Double basePrice;
    private Double pricePerUnit;
    private String unit;
    private Integer estimatedDurationHours;
    private Boolean isActive;
    private String iconUrl;
    
    public double calculatePrice(int quantity) {
        return basePrice + (pricePerUnit * quantity);
    }
}
