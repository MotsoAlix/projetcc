package com.pressing.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderStatisticsDTO {
    private Long totalOrders;
    private Long todayOrders;
    private Long pendingOrders;
    private Long inProgressOrders;
    private Long readyOrders;
    private Long deliveredOrders;
    private Long cancelledOrders;
    private Double totalRevenue;
    private Double todayRevenue;
}
