package com.pressing.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessageDTO {
    private String id;
    private String conversationId;
    private String senderId;
    private String senderName;
    private String senderAvatar;
    private String content;
    private LocalDateTime sentAt;
    private LocalDateTime readAt;
    @Builder.Default
    private List<String> attachments = new ArrayList<>();
    private Boolean isSystem;
    
    @Transient
    public boolean isRead() {
        return readAt != null;
    }
    
    @Transient
    public String getTimeFormatted() {
        if (sentAt == null) return "";
        return String.format("%02d:%02d", sentAt.getHour(), sentAt.getMinute());
    }
}
