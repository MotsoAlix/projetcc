package com.pressing.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReceiptItemDTO {
    private String id;
    private String description;
    private Integer quantity;
    private Double unitPrice;
    private Double totalPrice;
}
