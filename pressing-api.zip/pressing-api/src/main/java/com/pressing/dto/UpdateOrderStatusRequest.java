package com.pressing.dto;

import com.pressing.enums.OrderStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateOrderStatusRequest {
    
    @NotNull(message = "Le statut est requis")
    private OrderStatus status;
}
