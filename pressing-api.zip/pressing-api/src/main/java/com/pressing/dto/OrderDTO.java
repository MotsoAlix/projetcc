package com.pressing.dto;

import com.pressing.enums.OrderStatus;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderDTO {
    private String id;
    private String orderNumber;
    private String clientId;
    private UserDTO client;
    private String employeeId;
    private UserDTO employee;
    @Builder.Default
    private List<OrderItemDTO> items = new ArrayList<>();
    private OrderStatus status;
    private Double totalAmount;
    private LocalDateTime createdAt;
    private LocalDateTime receivedAt;
    private LocalDateTime readyAt;
    private LocalDateTime deliveredAt;
    private LocalDateTime estimatedReadyAt;
    private String notes;
    private String deliveryAddress;
    private Boolean isDelivery;
    private Boolean isPaid;
    private LocalDateTime paidAt;
    private String paymentMethod;
    
    @Transient
    public int getTotalItems() {
        return items.stream().mapToInt(OrderItemDTO::getQuantity).sum();
    }
}
