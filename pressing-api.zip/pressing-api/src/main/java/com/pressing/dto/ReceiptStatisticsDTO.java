package com.pressing.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReceiptStatisticsDTO {
    private Long totalReceipts;
    private Long paidReceipts;
    private Long unpaidReceipts;
    private Double totalRevenue;
    private Double outstandingAmount;
}
