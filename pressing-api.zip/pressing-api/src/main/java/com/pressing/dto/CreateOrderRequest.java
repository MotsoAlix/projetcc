package com.pressing.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class CreateOrderRequest {
    
    @NotBlank(message = "L'ID client est requis")
    private String clientId;
    
    private String employeeId;
    
    @NotEmpty(message = "Au moins un article est requis")
    @Valid
    private List<OrderItemRequest> items;
    
    private String notes;
    
    private String deliveryAddress;
    
    private Boolean isDelivery = false;
    
    private LocalDateTime estimatedReadyAt;
}
