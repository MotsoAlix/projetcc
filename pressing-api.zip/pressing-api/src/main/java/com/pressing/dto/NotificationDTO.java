package com.pressing.dto;

import com.pressing.enums.NotificationType;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationDTO {
    private String id;
    private String userId;
    private NotificationType type;
    private String title;
    private String body;
    private String imageUrl;
    private String actionUrl;
    private String relatedId;
    private Boolean isRead;
    private LocalDateTime createdAt;
    private LocalDateTime readAt;
    
    @Transient
    public String getTypeIcon() {
        return switch (type) {
            case ORDER_CREATED -> "shopping_bag";
            case ORDER_STATUS_CHANGED -> "sync_alt";
            case ORDER_READY -> "check_circle";
            case ORDER_DELIVERED -> "delivery_dining";
            case MESSAGE_RECEIVED -> "chat_bubble";
            case PAYMENT_RECEIVED -> "payments";
            case PROMOTION -> "local_offer";
            case SYSTEM -> "info";
        };
    }
    
    @Transient
    public String getTypeColor() {
        return switch (type) {
            case ORDER_CREATED -> "#2196F3";
            case ORDER_STATUS_CHANGED -> "#FF9800";
            case ORDER_READY -> "#4CAF50";
            case ORDER_DELIVERED -> "#009688";
            case MESSAGE_RECEIVED -> "#9C27B0";
            case PAYMENT_RECEIVED -> "#2E7D32";
            case PROMOTION -> "#E91E63";
            case SYSTEM -> "#757575";
        };
    }
}
