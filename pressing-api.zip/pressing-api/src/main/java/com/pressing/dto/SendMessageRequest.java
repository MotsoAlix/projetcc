package com.pressing.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class SendMessageRequest {
    
    @NotBlank(message = "Le contenu du message est requis")
    private String content;
    
    private List<String> attachments;
}
