package com.pressing.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderItemRequest {
    
    @NotBlank(message = "L'ID du service est requis")
    private String serviceId;
    
    @NotNull(message = "La quantité est requise")
    @Min(value = 1, message = "La quantité doit être d'au moins 1")
    private Integer quantity;
    
    private String notes;
}
