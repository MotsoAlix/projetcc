package com.pressing.dto;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderItemDTO {
    private String id;
    private String orderId;
    private PressingServiceDTO service;
    private Integer quantity;
    private String notes;
    @Builder.Default
    private List<String> photoUrls = new ArrayList<>();
    private Double unitPrice;
    
    @Transient
    public Double getTotalPrice() {
        return unitPrice * quantity;
    }
}
