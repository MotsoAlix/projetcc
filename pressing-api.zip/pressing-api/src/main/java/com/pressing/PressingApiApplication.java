package com.pressing;

import com.pressing.service.PressingServiceService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PressingApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PressingApiApplication.class, args);
    }

    @Bean
    CommandLineRunner init(PressingServiceService serviceService) {
        return args -> {
            // Initialize default services
            serviceService.initializeDefaultServices();
        };
    }
}
