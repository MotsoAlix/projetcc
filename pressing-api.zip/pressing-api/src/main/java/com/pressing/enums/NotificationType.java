package com.pressing.enums;

public enum NotificationType {
    ORDER_CREATED,
    ORDER_STATUS_CHANGED,
    ORDER_READY,
    ORDER_DELIVERED,
    MESSAGE_RECEIVED,
    PAYMENT_RECEIVED,
    PROMOTION,
    SYSTEM
}
