package com.pressing.enums;

public enum ServiceType {
    WASHING("Lavage", "local_laundry_service", 5.0, 24),
    DRY_CLEANING("Nettoyage à sec", "dry_cleaning", 12.0, 48),
    IRONING("Repassage", "iron", 3.0, 12),
    STAIN_REMOVAL("Détachage", "cleaning_services", 15.0, 72),
    REPAIR("Retouche", "content_cut", 15.0, 72),
    LEATHER_CARE("Entretien cuir", "checkroom", 35.0, 120),
    WEDDING_DRESS("Robe de mariée", "favorite", 180.0, 336),
    DUVET("Couette/Duvet", "bed", 25.0, 72),
    CARPET("Tapis", "square_foot", 45.0, 168);

    private final String displayName;
    private final String icon;
    private final double basePrice;
    private final int estimatedDurationHours;

    ServiceType(String displayName, String icon, double basePrice, int estimatedDurationHours) {
        this.displayName = displayName;
        this.icon = icon;
        this.basePrice = basePrice;
        this.estimatedDurationHours = estimatedDurationHours;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getIcon() {
        return icon;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public int getEstimatedDurationHours() {
        return estimatedDurationHours;
    }

    public double calculatePrice(int quantity) {
        return basePrice * quantity;
    }
}
