package com.pressing.enums;

public enum UserRole {
    ADMIN,
    EMPLOYEE,
    CLIENT;

    public String getDisplayName() {
        return switch (this) {
            case ADMIN -> "Administrateur";
            case EMPLOYEE -> "Employé";
            case CLIENT -> "Client";
        };
    }

    public boolean canCreateOrder() {
        return this == ADMIN || this == EMPLOYEE;
    }

    public boolean canManageUsers() {
        return this == ADMIN;
    }

    public boolean canAccessAllOrders() {
        return this == ADMIN || this == EMPLOYEE;
    }

    public boolean canUpdateOrderStatus() {
        return this == ADMIN || this == EMPLOYEE;
    }
}
