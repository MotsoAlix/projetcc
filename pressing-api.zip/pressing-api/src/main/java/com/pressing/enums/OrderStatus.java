package com.pressing.enums;

public enum OrderStatus {
    PENDING("En attente", "#FF9800"),
    RECEIVED("Reçue", "#2196F3"),
    IN_PROGRESS("En traitement", "#9C27B0"),
    READY("Prête", "#4CAF50"),
    DELIVERED("Livrée", "#2E7D32"),
    CANCELLED("Annulée", "#F44336");

    private final String displayName;
    private final String color;

    OrderStatus(String displayName, String color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getColor() {
        return color;
    }

    public boolean isActive() {
        return this != DELIVERED && this != CANCELLED;
    }

    public boolean canCancel() {
        return this == PENDING || this == RECEIVED;
    }

    public boolean canModify() {
        return this == PENDING || this == RECEIVED;
    }
}
