package com.pressing.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "order_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderItem {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "service_id", nullable = false)
    private PressingService service;
    
    @Column(nullable = false)
    private Integer quantity;
    
    @Column(length = 1000)
    private String notes;
    
    @ElementCollection
    @CollectionTable(name = "order_item_photos", joinColumns = @JoinColumn(name = "order_item_id"))
    @Column(name = "photo_url")
    @Builder.Default
    private List<String> photoUrls = new ArrayList<>();
    
    @Column(nullable = false)
    private Double unitPrice;
    
    @Transient
    public Double getTotalPrice() {
        return unitPrice * quantity;
    }
    
    public void addPhoto(String url) {
        photoUrls.add(url);
    }
    
    public void removePhoto(String url) {
        photoUrls.remove(url);
    }
}
