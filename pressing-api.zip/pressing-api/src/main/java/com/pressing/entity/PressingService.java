package com.pressing.entity;

import com.pressing.enums.ServiceType;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "services")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PressingService {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, unique = true)
    private ServiceType type;
    
    @Column(nullable = false)
    private String name;
    
    @Column(length = 1000)
    private String description;
    
    @Column(nullable = false)
    private Double basePrice;
    
    @Column(nullable = false)
    private Double pricePerUnit;
    
    @Column(nullable = false)
    private String unit;
    
    @Column(nullable = false)
    private Integer estimatedDurationHours;
    
    @Builder.Default
    private Boolean isActive = true;
    
    private String iconUrl;
    
    public double calculatePrice(int quantity) {
        return basePrice + (pricePerUnit * quantity);
    }
}
