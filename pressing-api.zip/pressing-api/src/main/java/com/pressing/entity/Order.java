package com.pressing.entity;

import com.pressing.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Order {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false, unique = true)
    private String orderNumber;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id", nullable = false)
    private User client;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private User employee;
    
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<OrderItem> items = new ArrayList<>();
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private OrderStatus status = OrderStatus.PENDING;
    
    @Column(nullable = false)
    private Double totalAmount;
    
    @CreationTimestamp
    private LocalDateTime createdAt;
    
    private LocalDateTime receivedAt;
    
    private LocalDateTime readyAt;
    
    private LocalDateTime deliveredAt;
    
    private LocalDateTime estimatedReadyAt;
    
    @Column(length = 2000)
    private String notes;
    
    private String deliveryAddress;
    
    @Builder.Default
    private Boolean isDelivery = false;
    
    @Builder.Default
    private Boolean isPaid = false;
    
    private LocalDateTime paidAt;
    
    private String paymentMethod;
    
    public void addItem(OrderItem item) {
        items.add(item);
        item.setOrder(this);
        recalculateTotal();
    }
    
    public void removeItem(OrderItem item) {
        items.remove(item);
        item.setOrder(null);
        recalculateTotal();
    }
    
    public void recalculateTotal() {
        this.totalAmount = items.stream()
                .mapToDouble(OrderItem::getTotalPrice)
                .sum();
    }
    
    @Transient
    public int getTotalItems() {
        return items.stream().mapToInt(OrderItem::getQuantity).sum();
    }
    
    @Transient
    public boolean isActive() {
        return status.isActive();
    }
    
    @Transient
    public boolean canCancel() {
        return status.canCancel();
    }
    
    @Transient
    public boolean canModify() {
        return status.canModify();
    }
}
