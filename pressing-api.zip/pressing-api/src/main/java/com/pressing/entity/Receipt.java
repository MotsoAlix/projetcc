package com.pressing.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "receipts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Receipt {
    
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    
    @Column(nullable = false, unique = true)
    private String receiptNumber;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client_id", nullable = false)
    private User client;
    
    @Column(nullable = false)
    private String clientName;
    
    private String clientAddress;
    
    private String clientEmail;
    
    private String clientPhone;
    
    @CreationTimestamp
    private LocalDateTime issueDate;
    
    private LocalDateTime dueDate;
    
    @OneToMany(mappedBy = "receipt", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<ReceiptItem> items = new ArrayList<>();
    
    @Column(nullable = false)
    private Double subtotal;
    
    @Column(nullable = false)
    private Double taxRate;
    
    @Column(nullable = false)
    private Double taxAmount;
    
    @Column(nullable = false)
    private Double totalAmount;
    
    private Double amountPaid;
    
    private Double amountDue;
    
    private String paymentMethod;
    
    private LocalDateTime paymentDate;
    
    @Builder.Default
    private Boolean isPaid = false;
    
    @Column(length = 2000)
    private String notes;
    
    private String terms;
    
    private String pdfUrl;
    
    public void addItem(ReceiptItem item) {
        items.add(item);
        item.setReceipt(this);
    }
    
    @Transient
    public String getFormattedNumber() {
        return "FAC-" + receiptNumber;
    }
    
    public void markAsPaid(String method, double amount) {
        this.isPaid = true;
        this.paymentMethod = method;
        this.paymentDate = LocalDateTime.now();
        this.amountPaid = amount;
        this.amountDue = 0.0;
    }
}
