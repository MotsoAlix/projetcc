package com.pressing.config;

import com.pressing.entity.User;
import com.pressing.enums.UserRole;
import com.pressing.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create test users if they don't exist
        createUserIfNotExists("admin@pressing.com", "admin123", "Marie", "Dupont", "0612345678", UserRole.ADMIN);
        createUserIfNotExists("employe@pressing.com", "employe123", "Jean", "Martin", "0698765432", UserRole.EMPLOYEE);
        createUserIfNotExists("client@email.com", "client123", "Sophie", "Bernard", "0678901234", UserRole.CLIENT);
        createUserIfNotExists("pierre.durand@email.com", "client123", "Pierre", "Durand", "0611223344", UserRole.CLIENT);
        createUserIfNotExists("marie.lefevre@email.com", "client123", "Marie", "Lefevre", "0622334455", UserRole.CLIENT);
    }

    private void createUserIfNotExists(String email, String password, String firstName, 
                                       String lastName, String phone, UserRole role) {
        if (!userRepository.existsByEmail(email)) {
            User user = User.builder()
                    .email(email)
                    .password(passwordEncoder.encode(password))
                    .firstName(firstName)
                    .lastName(lastName)
                    .phone(phone)
                    .role(role)
                    .isActive(true)
                    .build();
            userRepository.save(user);
            System.out.println("Created user: " + email + " with role: " + role);
        }
    }
}
