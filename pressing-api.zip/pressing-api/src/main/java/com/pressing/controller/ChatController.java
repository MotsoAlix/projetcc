package com.pressing.controller;

import com.pressing.dto.*;
import com.pressing.service.ChatService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/chat")
@Tag(name = "Chat", description = "Messagerie")
@CrossOrigin(origins = "*")
public class ChatController {

    @Autowired
    private ChatService chatService;

    @GetMapping("/conversations")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer les conversations de l'utilisateur")
    public ResponseEntity<ApiResponse<List<ConversationDTO>>> getUserConversations(
            @AuthenticationPrincipal UserDetails userDetails) {
        String userId = extractUserId(userDetails);
        List<ConversationDTO> conversations = chatService.getUserConversations(userId);
        return ResponseEntity.ok(ApiResponse.success(conversations));
    }

    @GetMapping("/conversations/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer une conversation par ID")
    public ResponseEntity<ApiResponse<ConversationDTO>> getConversation(
            @PathVariable String id,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            String userId = extractUserId(userDetails);
            ConversationDTO conversation = chatService.getConversation(id, userId);
            return ResponseEntity.ok(ApiResponse.success(conversation));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/conversations/{id}/messages")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer les messages d'une conversation")
    public ResponseEntity<ApiResponse<List<MessageDTO>>> getConversationMessages(@PathVariable String id) {
        List<MessageDTO> messages = chatService.getConversationMessages(id);
        return ResponseEntity.ok(ApiResponse.success(messages));
    }

    @PostMapping("/conversations/{id}/messages")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Envoyer un message")
    public ResponseEntity<ApiResponse<MessageDTO>> sendMessage(
            @PathVariable String id,
            @Valid @RequestBody SendMessageRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            String userId = extractUserId(userDetails);
            MessageDTO message = chatService.sendMessage(id, userId, request);
            return ResponseEntity.ok(ApiResponse.success("Message envoyé", message));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/conversations/{id}/read")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Marquer tous les messages comme lus")
    public ResponseEntity<ApiResponse<Void>> markAllAsRead(
            @PathVariable String id,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            String userId = extractUserId(userDetails);
            chatService.markAllAsRead(id, userId);
            return ResponseEntity.ok(ApiResponse.success("Messages marqués comme lus", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/unread-count")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer le nombre de messages non lus")
    public ResponseEntity<ApiResponse<Integer>> getUnreadCount(
            @AuthenticationPrincipal UserDetails userDetails) {
        String userId = extractUserId(userDetails);
        int count = chatService.getUnreadCount(userId);
        return ResponseEntity.ok(ApiResponse.success(count));
    }

    private String extractUserId(UserDetails userDetails) {
        // TODO: Implement proper user ID extraction from UserDetails
        return userDetails.getUsername();
    }
}
