package com.pressing.controller;

import com.pressing.dto.ApiResponse;
import com.pressing.dto.PressingServiceDTO;
import com.pressing.service.PressingServiceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/services")
@Tag(name = "Services", description = "Gestion des services de pressing")
@CrossOrigin(origins = "*")
public class ServiceController {

    @Autowired
    private PressingServiceService serviceService;

    @GetMapping
    @Operation(summary = "Récupérer tous les services")
    public ResponseEntity<ApiResponse<List<PressingServiceDTO>>> getAllServices() {
        List<PressingServiceDTO> services = serviceService.getAllServices();
        return ResponseEntity.ok(ApiResponse.success(services));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Récupérer un service par ID")
    public ResponseEntity<ApiResponse<PressingServiceDTO>> getServiceById(@PathVariable String id) {
        try {
            PressingServiceDTO service = serviceService.getServiceById(id);
            return ResponseEntity.ok(ApiResponse.success(service));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
