package com.pressing.controller;

import com.pressing.dto.*;
import com.pressing.enums.OrderStatus;
import com.pressing.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
@Tag(name = "Commandes", description = "Gestion des commandes")
@CrossOrigin(origins = "*")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Récupérer toutes les commandes")
    public ResponseEntity<ApiResponse<List<OrderDTO>>> getAllOrders() {
        List<OrderDTO> orders = orderService.getAllOrders();
        return ResponseEntity.ok(ApiResponse.success(orders));
    }

    @GetMapping("/client/{clientId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE') or @orderSecurity.isClientOwner(#clientId, authentication)")
    @Operation(summary = "Récupérer les commandes d'un client")
    public ResponseEntity<ApiResponse<List<OrderDTO>>> getOrdersByClient(@PathVariable String clientId) {
        List<OrderDTO> orders = orderService.getOrdersByClient(clientId);
        return ResponseEntity.ok(ApiResponse.success(orders));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer une commande par ID")
    public ResponseEntity<ApiResponse<OrderDTO>> getOrderById(@PathVariable String id) {
        try {
            OrderDTO order = orderService.getOrderById(id);
            return ResponseEntity.ok(ApiResponse.success(order));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Créer une nouvelle commande")
    public ResponseEntity<ApiResponse<OrderDTO>> createOrder(
            @Valid @RequestBody CreateOrderRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            // Extract user ID from userDetails
            String employeeId = null; // TODO: Get from userDetails
            OrderDTO order = orderService.createOrder(request, employeeId);
            return ResponseEntity.ok(ApiResponse.success("Commande créée avec succès", order));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Mettre à jour le statut d'une commande")
    public ResponseEntity<ApiResponse<OrderDTO>> updateOrderStatus(
            @PathVariable String id,
            @Valid @RequestBody UpdateOrderStatusRequest request,
            @AuthenticationPrincipal UserDetails userDetails) {
        try {
            String userId = null; // TODO: Get from userDetails
            OrderDTO order = orderService.updateOrderStatus(id, request.getStatus(), userId);
            return ResponseEntity.ok(ApiResponse.success("Statut mis à jour", order));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/{id}/pay")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Marquer une commande comme payée")
    public ResponseEntity<ApiResponse<OrderDTO>> markAsPaid(
            @PathVariable String id,
            @RequestBody PaymentRequest request) {
        try {
            OrderDTO order = orderService.markAsPaid(id, request.getPaymentMethod());
            return ResponseEntity.ok(ApiResponse.success("Paiement enregistré", order));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Supprimer une commande")
    public ResponseEntity<ApiResponse<Void>> deleteOrder(@PathVariable String id) {
        try {
            orderService.deleteOrder(id);
            return ResponseEntity.ok(ApiResponse.success("Commande supprimée", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/statistics")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Récupérer les statistiques des commandes")
    public ResponseEntity<ApiResponse<OrderStatisticsDTO>> getStatistics() {
        OrderStatisticsDTO stats = orderService.getStatistics();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
