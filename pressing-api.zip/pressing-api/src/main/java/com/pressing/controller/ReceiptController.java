package com.pressing.controller;

import com.pressing.dto.*;
import com.pressing.service.ReceiptService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/receipts")
@Tag(name = "Reçus", description = "Gestion des reçus et factures")
@CrossOrigin(origins = "*")
public class ReceiptController {

    @Autowired
    private ReceiptService receiptService;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Récupérer tous les reçus")
    public ResponseEntity<ApiResponse<List<ReceiptDTO>>> getAllReceipts() {
        List<ReceiptDTO> receipts = receiptService.getAllReceipts();
        return ResponseEntity.ok(ApiResponse.success(receipts));
    }

    @GetMapping("/client/{clientId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE') or @receiptSecurity.isClientOwner(#clientId, authentication)")
    @Operation(summary = "Récupérer les reçus d'un client")
    public ResponseEntity<ApiResponse<List<ReceiptDTO>>> getReceiptsByClient(@PathVariable String clientId) {
        List<ReceiptDTO> receipts = receiptService.getReceiptsByClient(clientId);
        return ResponseEntity.ok(ApiResponse.success(receipts));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Récupérer un reçu par ID")
    public ResponseEntity<ApiResponse<ReceiptDTO>> getReceiptById(@PathVariable String id) {
        try {
            ReceiptDTO receipt = receiptService.getReceiptById(id);
            return ResponseEntity.ok(ApiResponse.success(receipt));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/generate/{orderId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Générer un reçu pour une commande")
    public ResponseEntity<ApiResponse<ReceiptDTO>> generateReceipt(@PathVariable String orderId) {
        try {
            ReceiptDTO receipt = receiptService.generateReceipt(orderId);
            return ResponseEntity.ok(ApiResponse.success("Reçu généré avec succès", receipt));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @PostMapping("/{id}/pay")
    @PreAuthorize("hasRole('ADMIN') or hasRole('EMPLOYEE')")
    @Operation(summary = "Marquer un reçu comme payé")
    public ResponseEntity<ApiResponse<ReceiptDTO>> markAsPaid(
            @PathVariable String id,
            @RequestBody PaymentRequest request) {
        try {
            ReceiptDTO receipt = receiptService.markAsPaid(id, request.getPaymentMethod(), 0);
            return ResponseEntity.ok(ApiResponse.success("Paiement enregistré", receipt));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Supprimer un reçu")
    public ResponseEntity<ApiResponse<Void>> deleteReceipt(@PathVariable String id) {
        try {
            receiptService.deleteReceipt(id);
            return ResponseEntity.ok(ApiResponse.success("Reçu supprimé", null));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/statistics")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Récupérer les statistiques des reçus")
    public ResponseEntity<ApiResponse<ReceiptStatisticsDTO>> getStatistics() {
        ReceiptStatisticsDTO stats = receiptService.getStatistics();
        return ResponseEntity.ok(ApiResponse.success(stats));
    }
}
