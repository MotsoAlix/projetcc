# Pressing API - Spring Boot

API REST complète pour l'application de gestion de pressing.

## 🚀 Démarrage rapide

### Prérequis
- Java 17+
- Maven 3.8+
- (Optionnel) PostgreSQL 14+ pour la production

### Installation

1. **Naviguer dans le dossier du projet**
```bash
cd pressing-api
```

2. **Compiler et exécuter**
```bash
mvn clean install
mvn spring-boot:run
```

3. **Accéder à l'API**
- API Base URL: `http://localhost:8080/api`
- Swagger UI: `http://localhost:8080/api/swagger-ui.html`
- H2 Console: `http://localhost:8080/api/h2-console`

## 📁 Structure du projet

```
pressing-api/
├── src/main/java/com/pressing/
│   ├── PressingApiApplication.java
│   ├── config/              # Configuration (Security, WebSocket, etc.)
│   ├── controller/          # REST Controllers
│   ├── service/             # Business Logic
│   ├── repository/          # JPA Repositories
│   ├── entity/              # JPA Entities
│   ├── dto/                 # Data Transfer Objects
│   ├── enums/               # Enumerations
│   ├── security/            # JWT & Security
│   └── websocket/           # WebSocket Handlers
└── src/main/resources/
    └── application.yml      # Configuration
```

## 🔐 Authentification

L'API utilise JWT (JSON Web Token) pour l'authentification.

### Header d'authentification
```
Authorization: Bearer <token>
```

### Comptes de test

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| **Admin** | `admin@pressing.com` | `admin123` |
| **Employé** | `employe@pressing.com` | `employe123` |
| **Client** | `client@email.com` | `client123` |

## 📚 Endpoints API

### Authentification
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| POST | `/auth/login` | Connexion |
| POST | `/auth/register` | Inscription |
| POST | `/auth/refresh` | Rafraîchir token |

### Utilisateurs
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/users` | Liste des utilisateurs (Admin) |
| GET | `/users/{id}` | Détail utilisateur |
| GET | `/users/clients` | Liste des clients |

### Commandes
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/orders` | Liste des commandes |
| GET | `/orders/{id}` | Détail commande |
| POST | `/orders` | Créer commande |
| PUT | `/orders/{id}/status` | Changer statut |
| POST | `/orders/{id}/pay` | Marquer payée |
| GET | `/orders/statistics` | Statistiques |

### Services
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/services` | Liste des services |

### Chat
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/chat/conversations` | Conversations |
| GET | `/chat/conversations/{id}/messages` | Messages |
| POST | `/chat/conversations/{id}/messages` | Envoyer message |

### Notifications
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/notifications` | Notifications |
| GET | `/notifications/unread-count` | Non lues |
| POST | `/notifications/read-all` | Tout lire |

### Reçus
| Méthode | Endpoint | Description |
|---------|----------|-------------|
| GET | `/receipts` | Liste des reçus |
| POST | `/receipts/generate/{orderId}` | Générer reçu |
| POST | `/receipts/{id}/pay` | Marquer payé |

## 🗄 Base de données

### Développement (H2)
Par défaut, l'application utilise H2 en mémoire.

### Production (PostgreSQL)
```bash
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

Ou définir les variables d'environnement:
```bash
export DB_USERNAME=pressing
export DB_PASSWORD=pressing123
mvn spring-boot:run
```

## 🔧 Configuration

### application.yml
```yaml
server:
  port: 8080

jwt:
  secret: votre-secret-key
  expiration: 86400000  # 24h

storage:
  path: ./uploads
```

## 📦 Dépendances principales

- Spring Boot 3.2
- Spring Security + JWT
- Spring Data JPA
- Spring WebSocket
- H2 / PostgreSQL
- Lombok
- OpenAPI/Swagger

## 🌐 WebSocket

Le chat utilise WebSocket avec STOMP.

**Endpoint:** `ws://localhost:8080/api/ws`

**Topics:**
- `/topic/messages/{conversationId}` - Messages d'une conversation
- `/topic/notifications/{userId}` - Notifications utilisateur

## 📝 Documentation API

Une fois l'application démarrée:
- **Swagger UI:** http://localhost:8080/api/swagger-ui.html
- **OpenAPI JSON:** http://localhost:8080/api/api-docs

## 🧪 Tests

```bash
# Lancer les tests
mvn test

# Tests avec couverture
mvn jacoco:report
```

## 🚀 Déploiement

### Build JAR
```bash
mvn clean package
java -jar target/pressing-api-1.0.0.jar
```

### Docker (optionnel)
```dockerfile
FROM openjdk:17-jdk-slim
COPY target/pressing-api-1.0.0.jar app.jar
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

## 📄 Licence

Projet académique Master 2
